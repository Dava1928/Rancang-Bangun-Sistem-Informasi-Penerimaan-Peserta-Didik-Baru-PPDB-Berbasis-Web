<?php
// =========================================================
// File: index.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Halaman landing page / beranda
// =========================================================

$page_title = 'Beranda - PPDB Online MTS SA BINARAHMAH';

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<section class="hero-section">
    <div class="container position-relative">
        <div class="row align-items-center">
            <div class="col-lg-7">
                <span class="hero-kicker">
                    <i class="bi bi-stars"></i>
                    Penerimaan Peserta Didik Baru Online
                </span>
                <h1 class="hero-title">
                    PPDB Online<br>
                    MTS SA BINARAHMAH
                </h1>
                <p class="hero-subtitle">
                    Sistem informasi berbasis web untuk memudahkan calon peserta didik melakukan pendaftaran,
                    mengunggah dokumen persyaratan, dan memantau status verifikasi secara cepat, transparan,
                    dan terstruktur.
                </p>

                <div class="hero-actions">
                    <?php if (!is_logged_in()) : ?>
                        <a href="<?php echo BASE_URL; ?>register.php" class="btn btn-light btn-lg">
                            <i class="bi bi-person-plus me-2"></i>
                            Daftar Sekarang
                        </a>
                        <a href="<?php echo BASE_URL; ?>profil.php" class="btn btn-outline-light btn-lg">
                            <i class="bi bi-building me-2"></i>
                            Profil Madrasah
                        </a>
                    <?php elseif (is_admin()) : ?>
                        <a href="<?php echo BASE_URL; ?>admin/dashboard.php" class="btn btn-light btn-lg">
                            <i class="bi bi-speedometer2 me-2"></i>
                            Masuk Dashboard Admin
                        </a>
                    <?php else : ?>
                        <a href="<?php echo BASE_URL; ?>user/dashboard.php" class="btn btn-light btn-lg">
                            <i class="bi bi-speedometer2 me-2"></i>
                            Masuk Dashboard
                        </a>
                    <?php endif; ?>
                </div>

                <div class="hero-metrics">
                    <div class="hero-metric">
                        <strong>3</strong>
                        <span>Step Formulir</span>
                    </div>
                    <div class="hero-metric">
                        <strong>4</strong>
                        <span>Dokumen Wajib</span>
                    </div>
                    <div class="hero-metric">
                        <strong>24/7</strong>
                        <span>Akses Online</span>
                    </div>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="hero-card">
                    <div class="hero-card-icon">
                        <i class="bi bi-megaphone-fill"></i>
                    </div>
                    <h4 class="fw-bold text-primary-custom mb-3">Informasi PPDB</h4>
                    <p class="mb-3 text-muted">
                        Pendaftaran peserta didik baru MTS SA BINARAHMAH dapat dilakukan secara online melalui sistem ini.
                    </p>

                    <div class="mb-3">
                        <span class="badge bg-primary-custom mb-2">
                            Tahun Ajaran <?php echo date('Y'); ?>/<?php echo date('Y') + 1; ?>
                        </span>
                        <br>
                        <span class="badge bg-success">Pendaftaran Dibuka</span>
                    </div>

                    <hr>

                    <ul class="list-unstyled mb-0">
                        <li><i class="bi bi-check-circle-fill text-success me-2"></i>Registrasi akun calon peserta didik</li>
                        <li><i class="bi bi-check-circle-fill text-success me-2"></i>Formulir pendaftaran multi-step</li>
                        <li><i class="bi bi-check-circle-fill text-success me-2"></i>Upload dokumen persyaratan</li>
                        <li><i class="bi bi-check-circle-fill text-success me-2"></i>Pantau status pendaftaran</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="container mt-4">
    <?php echo get_flash(); ?>
</div>

<section class="feature-strip no-print">
    <div class="container">
        <div class="feature-strip-card">
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="d-flex align-items-center gap-3">
                        <div class="info-card-icon mb-0">
                            <i class="bi bi-laptop"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold text-primary-custom mb-1">Online dan Mudah</h6>
                            <small class="text-muted">Pendaftaran dapat dilakukan dari rumah.</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex align-items-center gap-3">
                        <div class="info-card-icon mb-0">
                            <i class="bi bi-database-check"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold text-primary-custom mb-1">Data Terpusat</h6>
                            <small class="text-muted">Data pendaftar tersimpan rapi di database.</small>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex align-items-center gap-3">
                        <div class="info-card-icon mb-0">
                            <i class="bi bi-shield-check"></i>
                        </div>
                        <div>
                            <h6 class="fw-bold text-primary-custom mb-1">Verifikasi Admin</h6>
                            <small class="text-muted">Panitia dapat memeriksa dan menetapkan status.</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-padding">
    <div class="container">
        <div class="text-center">
            <span class="section-kicker">
                <i class="bi bi-building-fill-check"></i>
                Profil Singkat
            </span>
            <h2 class="section-title">MTS SA BINARAHMAH</h2>
            <p class="section-subtitle">
                Madrasah Tsanawiyah berbasis Islam yang berkomitmen membentuk peserta didik beriman,
                bertaqwa, berilmu, berakhlak mulia, dan berdaya saing di era global.
            </p>
        </div>

        <div class="row g-4 align-items-center">
            <div class="col-lg-6">
                <div class="soft-panel h-100">
                    <h4 class="text-primary-custom fw-bold mb-3">Pendidikan dengan Nilai dan Teknologi</h4>
                    <p class="text-muted" style="line-height: 1.9;">
                        Sistem PPDB Online ini dibangun untuk meningkatkan kualitas layanan administrasi
                        penerimaan peserta didik baru. Calon peserta didik dan orang tua/wali dapat memperoleh
                        informasi, melakukan pendaftaran, dan memantau status pendaftaran dengan lebih praktis.
                    </p>
                    <a href="<?php echo BASE_URL; ?>profil.php" class="btn btn-outline-primary-custom">
                        <i class="bi bi-arrow-right-circle me-1"></i>
                        Lihat Profil Lengkap
                    </a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="row g-4">
                    <div class="col-sm-6">
                        <div class="info-card text-center">
                            <div class="info-card-icon mx-auto">
                                <i class="bi bi-book-fill"></i>
                            </div>
                            <h5>Berilmu</h5>
                            <p class="mb-0">Mendorong kualitas akademik dan pengembangan potensi siswa.</p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="info-card text-center">
                            <div class="info-card-icon mx-auto">
                                <i class="bi bi-heart-fill"></i>
                            </div>
                            <h5>Berakhlak</h5>
                            <p class="mb-0">Menanamkan nilai Islam dan karakter mulia dalam kegiatan belajar.</p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="info-card text-center">
                            <div class="info-card-icon mx-auto">
                                <i class="bi bi-people-fill"></i>
                            </div>
                            <h5>Kolaboratif</h5>
                            <p class="mb-0">Menjalin sinergi dengan orang tua, masyarakat, dan stakeholder.</p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="info-card text-center">
                            <div class="info-card-icon mx-auto">
                                <i class="bi bi-rocket-takeoff-fill"></i>
                            </div>
                            <h5>Adaptif</h5>
                            <p class="mb-0">Memanfaatkan teknologi untuk layanan administrasi yang efisien.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-padding bg-white">
    <div class="container">
        <div class="text-center">
            <span class="section-kicker">
                <i class="bi bi-calendar-event-fill"></i>
                Jadwal PPDB
            </span>
            <h2 class="section-title">Jadwal Pendaftaran</h2>
            <p class="section-subtitle">
                Berikut jadwal kegiatan Penerimaan Peserta Didik Baru MTS SA BINARAHMAH.
            </p>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="content-card">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover mb-0">
                            <thead>
                                <tr>
                                    <th style="width: 70px;">No</th>
                                    <th>Kegiatan</th>
                                    <th>Waktu Pelaksanaan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>1</td>
                                    <td>Pendaftaran Online</td>
                                    <td>1 Mei - 30 Juni <?php echo date('Y'); ?></td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>Upload Dokumen Persyaratan</td>
                                    <td>1 Mei - 30 Juni <?php echo date('Y'); ?></td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>Verifikasi Berkas oleh Panitia</td>
                                    <td>1 Juli - 7 Juli <?php echo date('Y'); ?></td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>Pengumuman Hasil Seleksi</td>
                                    <td>10 Juli <?php echo date('Y'); ?></td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>Daftar Ulang</td>
                                    <td>11 Juli - 20 Juli <?php echo date('Y'); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="alert alert-info mt-4 mb-0">
                        <i class="bi bi-info-circle-fill me-2"></i>
                        Jadwal dapat berubah sewaktu-waktu sesuai kebijakan panitia PPDB MTS SA BINARAHMAH.
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-padding">
    <div class="container">
        <div class="text-center">
            <span class="section-kicker">
                <i class="bi bi-file-earmark-check-fill"></i>
                Persyaratan
            </span>
            <h2 class="section-title">Syarat Pendaftaran</h2>
            <p class="section-subtitle">
                Siapkan data dan dokumen berikut sebelum mengisi formulir pendaftaran online.
            </p>
        </div>

        <div class="row g-4">
            <div class="col-lg-6">
                <div class="info-card">
                    <div class="info-card-icon">
                        <i class="bi bi-person-lines-fill"></i>
                    </div>
                    <h5>Data yang Harus Diisi</h5>
                    <ul class="icon-list">
                        <li><i class="bi bi-check-circle-fill"></i><span>Nama lengkap, NIK, NISN, tempat dan tanggal lahir.</span></li>
                        <li><i class="bi bi-check-circle-fill"></i><span>Jenis kelamin, agama, alamat, nomor telepon, dan asal sekolah.</span></li>
                        <li><i class="bi bi-check-circle-fill"></i><span>Data ayah, ibu, pekerjaan, nomor telepon, dan penghasilan orang tua.</span></li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="info-card">
                    <div class="info-card-icon">
                        <i class="bi bi-cloud-arrow-up-fill"></i>
                    </div>
                    <h5>Dokumen yang Diupload</h5>
                    <ul class="icon-list">
                        <li><i class="bi bi-check-circle-fill"></i><span>Pas foto calon peserta didik.</span></li>
                        <li><i class="bi bi-check-circle-fill"></i><span>Ijazah/STTB SD/MI atau surat keterangan lulus.</span></li>
                        <li><i class="bi bi-check-circle-fill"></i><span>Akta kelahiran dan kartu keluarga.</span></li>
                    </ul>
                    <div class="alert alert-warning mt-4 mb-0">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        Format file: PDF, JPG, JPEG, PNG. Ukuran maksimal setiap file adalah 2MB.
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-padding bg-soft-blue">
    <div class="container">
        <div class="text-center">
            <span class="section-kicker">
                <i class="bi bi-signpost-split-fill"></i>
                Alur Pendaftaran
            </span>
            <h2 class="section-title">4 Langkah Mudah Mendaftar</h2>
            <p class="section-subtitle">
                Ikuti tahapan berikut untuk menyelesaikan pendaftaran PPDB Online.
            </p>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-9">
                <div class="content-card">
                    <div class="timeline-item">
                        <div class="timeline-number">1</div>
                        <div class="timeline-content">
                            <h6>Registrasi Akun</h6>
                            <p>Buat akun menggunakan nama lengkap, email aktif, dan password.</p>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-number">2</div>
                        <div class="timeline-content">
                            <h6>Login ke Sistem</h6>
                            <p>Masuk menggunakan email dan password yang sudah didaftarkan.</p>
                        </div>
                    </div>
                    <div class="timeline-item">
                        <div class="timeline-number">3</div>
                        <div class="timeline-content">
                            <h6>Lengkapi Formulir</h6>
                            <p>Isi data pribadi, data orang tua, dan unggah dokumen persyaratan.</p>
                        </div>
                    </div>
                    <div class="timeline-item pb-0">
                        <div class="timeline-number">4</div>
                        <div class="timeline-content">
                            <h6>Pantau Status</h6>
                            <p>Lihat status pendaftaran setelah panitia melakukan verifikasi data.</p>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-5">
                    <?php if (!is_logged_in()) : ?>
                        <a href="<?php echo BASE_URL; ?>register.php" class="btn btn-primary-custom btn-lg">
                            <i class="bi bi-arrow-right-circle me-2"></i>
                            Mulai Pendaftaran
                        </a>
                    <?php elseif (is_user()) : ?>
                        <a href="<?php echo BASE_URL; ?>user/formulir.php" class="btn btn-primary-custom btn-lg">
                            <i class="bi bi-pencil-square me-2"></i>
                            Isi Formulir Pendaftaran
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
