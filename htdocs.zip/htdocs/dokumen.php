<?php
// =========================================================
// File: dokumen.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Secure document viewer: dokumen hanya bisa dilihat pemilik data atau admin
// =========================================================

require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/database.php';
require_login();

$pendaftaran_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$type = isset($_GET['type']) ? preg_replace('/[^a-z_]/', '', $_GET['type']) : '';

$allowed_types = [
    'foto' => 'Pas Foto',
    'ijazah_sd' => 'Ijazah/STTB SD/MI',
    'akta_kelahiran' => 'Akta Kelahiran',
    'kartu_keluarga' => 'Kartu Keluarga'
];

if ($pendaftaran_id <= 0 || !array_key_exists($type, $allowed_types)) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$sql = "
    SELECT p.user_id, d.$type AS file_name
    FROM pendaftaran p
    INNER JOIN dokumen d ON p.id = d.pendaftaran_id
    WHERE p.id = ?
    LIMIT 1
";

$data = db_fetch_one($sql, 'i', [$pendaftaran_id]);

if (!$data || empty($data['file_name'])) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

if (!is_admin() && (int) $data['user_id'] !== current_user_id()) {
    http_response_code(403);
    set_flash('error', 'Anda tidak memiliki akses untuk melihat dokumen tersebut.');
    header('Location: ' . BASE_URL . (is_user() ? 'user/status.php' : 'index.php'));
    exit;
}

$file_name = basename($data['file_name']);
$file_path = realpath(UPLOAD_PATH . $file_name);
$upload_root = realpath(UPLOAD_PATH);

if (!$file_path || !$upload_root || strpos($file_path, $upload_root) !== 0 || !is_file($file_path)) {
    http_response_code(404);
    require __DIR__ . '/404.php';
    exit;
}

$extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
$mime_map = [
    'pdf' => 'application/pdf',
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png' => 'image/png'
];

if (!isset($mime_map[$extension])) {
    http_response_code(403);
    exit('Tipe file tidak diizinkan.');
}

if (!headers_sent()) {
    header('Content-Type: ' . $mime_map[$extension]);
    header('Content-Length: ' . filesize($file_path));
    header('Content-Disposition: inline; filename="' . rawurlencode($allowed_types[$type]) . '.' . $extension . '"');
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
}

readfile($file_path);
exit;
