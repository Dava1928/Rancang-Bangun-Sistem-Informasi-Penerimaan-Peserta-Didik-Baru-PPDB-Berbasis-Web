<?php
// =========================================================
// File: config/session.php
// Sistem PPDB Online MTS SA BINARAHMAH
// MAX HARDENING: session, auth, CSRF, rate limit, headers
// =========================================================

if (!defined('APP_ENV')) {
    define('APP_ENV', 'production');
}

if (!headers_sent()) {
    $is_https_header = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
        (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443) ||
        (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=()');
    header("Content-Security-Policy: default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'self'; object-src 'none'; script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net https://fonts.googleapis.com; font-src 'self' https://cdn.jsdelivr.net https://fonts.gstatic.com data:; img-src 'self' data: blob:; connect-src 'self'; media-src 'self';");

    if ($is_https_header) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

if (session_status() === PHP_SESSION_NONE) {
    $is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
        (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443) ||
        (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.cookie_httponly', '1');
    ini_set('session.cookie_samesite', 'Lax');
    ini_set('session.gc_maxlifetime', '7200');
    session_name('PPDB_BINARAHMAH_SESSID');

    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '',
        'secure' => $is_https,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);

    session_start();
}

define('BASE_URL', '/');
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('UPLOAD_URL', BASE_URL . 'uploads/');
define('SESSION_IDLE_LIMIT', 1800);        // 30 menit tidak aktif
define('SESSION_ABSOLUTE_LIMIT', 21600);   // 6 jam maksimum sesi login
define('CSRF_TOKEN_LIFETIME', 7200);       // 2 jam

// Regenerasi session berkala untuk mengurangi risiko session fixation.
if (!isset($_SESSION['__created_at'])) {
    $_SESSION['__created_at'] = time();
}

if (!isset($_SESSION['__last_regenerated'])) {
    $_SESSION['__last_regenerated'] = time();
} elseif (time() - (int) $_SESSION['__last_regenerated'] > 900) {
    session_regenerate_id(true);
    $_SESSION['__last_regenerated'] = time();
}

// Timeout otomatis untuk sesi login.
if (isset($_SESSION['user_id'])) {
    $now = time();
    $last_activity = (int) ($_SESSION['__last_activity'] ?? $now);
    $created_at = (int) ($_SESSION['__created_at'] ?? $now);

    if (($now - $last_activity) > SESSION_IDLE_LIMIT || ($now - $created_at) > SESSION_ABSOLUTE_LIMIT) {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
        session_start();
        $_SESSION['flash'] = [
            'type' => 'warning',
            'message' => 'Sesi Anda berakhir karena tidak aktif. Silakan login kembali.'
        ];
    } else {
        $_SESSION['__last_activity'] = $now;
        if (!headers_sent()) {
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
        }
    }
}

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function set_flash($type, $message)
{
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function get_flash()
{
    if (!isset($_SESSION['flash'])) {
        return '';
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);

    $alert_class = 'alert-info';
    $icon = 'bi-info-circle-fill';

    if ($flash['type'] === 'success') {
        $alert_class = 'alert-success';
        $icon = 'bi-check-circle-fill';
    } elseif ($flash['type'] === 'error') {
        $alert_class = 'alert-danger';
        $icon = 'bi-exclamation-triangle-fill';
    } elseif ($flash['type'] === 'warning') {
        $alert_class = 'alert-warning';
        $icon = 'bi-exclamation-circle-fill';
    }

    return '<div class="alert ' . $alert_class . ' alert-dismissible fade show" role="alert">'
        . '<i class="bi ' . $icon . ' me-2"></i>'
        . e($flash['message'])
        . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>'
        . '</div>';
}

function csrf_token()
{
    $now = time();

    if (empty($_SESSION['csrf_token']) || empty($_SESSION['csrf_token_time']) || ($now - (int) $_SESSION['csrf_token_time']) > CSRF_TOKEN_LIFETIME) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        $_SESSION['csrf_token_time'] = $now;
    }

    return $_SESSION['csrf_token'];
}

function csrf_field()
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf_token($token)
{
    if (empty($_SESSION['csrf_token']) || empty($_SESSION['csrf_token_time']) || !is_string($token)) {
        return false;
    }

    if ((time() - (int) $_SESSION['csrf_token_time']) > CSRF_TOKEN_LIFETIME) {
        return false;
    }

    return hash_equals($_SESSION['csrf_token'], $token);
}

function rotate_csrf_token()
{
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    $_SESSION['csrf_token_time'] = time();
}

function client_ip()
{
    return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
}

function rate_limit_key($name)
{
    return 'rate_' . preg_replace('/[^a-zA-Z0-9_\-]/', '_', $name);
}

function rate_limit_exceeded($name, $max_attempts, $seconds)
{
    $key = rate_limit_key($name);
    $now = time();

    if (!isset($_SESSION[$key]) || !is_array($_SESSION[$key])) {
        $_SESSION[$key] = [];
    }

    $_SESSION[$key] = array_filter($_SESSION[$key], function ($timestamp) use ($now, $seconds) {
        return ($now - (int) $timestamp) < $seconds;
    });

    return count($_SESSION[$key]) >= $max_attempts;
}

function rate_limit_hit($name)
{
    $key = rate_limit_key($name);
    if (!isset($_SESSION[$key]) || !is_array($_SESSION[$key])) {
        $_SESSION[$key] = [];
    }
    $_SESSION[$key][] = time();
}

function rate_limit_clear($name)
{
    $key = rate_limit_key($name);
    unset($_SESSION[$key]);
}

function is_logged_in()
{
    return isset($_SESSION['user_id'], $_SESSION['role']);
}

function is_admin()
{
    return is_logged_in() && $_SESSION['role'] === 'admin';
}

function is_user()
{
    return is_logged_in() && $_SESSION['role'] === 'user';
}

function require_login()
{
    if (!is_logged_in()) {
        set_flash('warning', 'Silakan login terlebih dahulu.');
        header('Location: ' . BASE_URL . 'login.php');
        exit;
    }
}

function require_admin()
{
    require_login();
    if (!is_admin()) {
        set_flash('error', 'Anda tidak memiliki akses ke halaman admin.');
        header('Location: ' . BASE_URL . 'user/dashboard.php');
        exit;
    }
}

function require_user()
{
    require_login();
    if (!is_user()) {
        set_flash('error', 'Halaman ini hanya dapat diakses oleh calon peserta didik.');
        header('Location: ' . BASE_URL . 'admin/dashboard.php');
        exit;
    }
}

function redirect_if_logged_in()
{
    if (!is_logged_in()) {
        return;
    }

    header('Location: ' . BASE_URL . ($_SESSION['role'] === 'admin' ? 'admin/dashboard.php' : 'user/dashboard.php'));
    exit;
}

function login_user($user)
{
    session_regenerate_id(true);

    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
    $_SESSION['email'] = $user['email'];
    $_SESSION['role'] = $user['role'];
    $_SESSION['__created_at'] = time();
    $_SESSION['__last_activity'] = time();
    $_SESSION['__last_regenerated'] = time();
    rotate_csrf_token();
}

function logout_user()
{
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }

    session_destroy();
}

function current_user_id()
{
    return isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null;
}

function current_user_name()
{
    return $_SESSION['nama_lengkap'] ?? 'Pengguna';
}

function current_user_email()
{
    return $_SESSION['email'] ?? '-';
}

function current_user_role()
{
    return $_SESSION['role'] ?? null;
}

function secure_document_url($pendaftaran_id, $type)
{
    return BASE_URL . 'dokumen.php?id=' . (int) $pendaftaran_id . '&type=' . rawurlencode($type);
}
?>
