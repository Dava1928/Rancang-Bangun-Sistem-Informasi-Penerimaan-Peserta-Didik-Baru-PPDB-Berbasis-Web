<?php
// =========================================================
// File: config/database.php
// Sistem PPDB Online MTS SA BINARAHMAH
// MAX HARDENING: koneksi DB, prepared helpers, safe utilities
// =========================================================

$host     = "sql300.infinityfree.com";
$username = "if0_41839342";
$password = "nAyTIlWU6Cx9nU";
$database = "if0_41839342_ppdb_mts";

mysqli_report(MYSQLI_REPORT_OFF);

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    error_log('PPDB DB connection failed: ' . mysqli_connect_error());
    http_response_code(500);
    die('Koneksi database sedang bermasalah. Silakan hubungi administrator.');
}

mysqli_set_charset($conn, 'utf8mb4');
mysqli_query($conn, "SET time_zone = '+07:00'");

function clean_input($data)
{
    global $conn;

    $data = trim((string) $data);
    $data = str_replace("\0", '', $data);
    $data = strip_tags($data);
    $data = mysqli_real_escape_string($conn, $data);

    return $data;
}

function db_bind_params($stmt, $types, $params)
{
    if ($types === '' || empty($params)) {
        return true;
    }

    $refs = [];
    $refs[] = $types;

    foreach ($params as $key => $value) {
        $refs[] = &$params[$key];
    }

    return call_user_func_array([$stmt, 'bind_param'], $refs);
}

function db_fetch_one($sql, $types = '', $params = [])
{
    global $conn;

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        error_log('DB prepare failed: ' . mysqli_error($conn));
        return null;
    }

    if (!db_bind_params($stmt, $types, $params)) {
        error_log('DB bind failed: ' . mysqli_stmt_error($stmt));
        mysqli_stmt_close($stmt);
        return null;
    }

    if (!mysqli_stmt_execute($stmt)) {
        error_log('DB execute failed: ' . mysqli_stmt_error($stmt));
        mysqli_stmt_close($stmt);
        return null;
    }

    $result = mysqli_stmt_get_result($stmt);
    $row = $result ? mysqli_fetch_assoc($result) : null;
    mysqli_stmt_close($stmt);

    return $row ?: null;
}

function db_fetch_all($sql, $types = '', $params = [])
{
    global $conn;

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        error_log('DB prepare failed: ' . mysqli_error($conn));
        return [];
    }

    if (!db_bind_params($stmt, $types, $params)) {
        error_log('DB bind failed: ' . mysqli_stmt_error($stmt));
        mysqli_stmt_close($stmt);
        return [];
    }

    if (!mysqli_stmt_execute($stmt)) {
        error_log('DB execute failed: ' . mysqli_stmt_error($stmt));
        mysqli_stmt_close($stmt);
        return [];
    }

    $result = mysqli_stmt_get_result($stmt);
    $rows = [];

    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            $rows[] = $row;
        }
    }

    mysqli_stmt_close($stmt);
    return $rows;
}

function db_execute($sql, $types = '', $params = [])
{
    global $conn;

    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        error_log('DB prepare failed: ' . mysqli_error($conn));
        return false;
    }

    if (!db_bind_params($stmt, $types, $params)) {
        error_log('DB bind failed: ' . mysqli_stmt_error($stmt));
        mysqli_stmt_close($stmt);
        return false;
    }

    $ok = mysqli_stmt_execute($stmt);
    if (!$ok) {
        error_log('DB execute failed: ' . mysqli_stmt_error($stmt));
    }

    mysqli_stmt_close($stmt);
    return $ok;
}

// Backward-compatible helpers untuk file lama.
function query_single($query)
{
    global $conn;
    $result = mysqli_query($conn, $query);

    if (!$result) {
        error_log('DB query_single failed: ' . mysqli_error($conn));
        return null;
    }

    if (mysqli_num_rows($result) > 0) {
        return mysqli_fetch_assoc($result);
    }

    return null;
}

function query_all($query)
{
    global $conn;
    $result = mysqli_query($conn, $query);
    $rows = [];

    if (!$result) {
        error_log('DB query_all failed: ' . mysqli_error($conn));
        return [];
    }

    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }

    return $rows;
}

function email_exists($email)
{
    $email = strtolower(trim((string) $email));
    return db_fetch_one('SELECT id FROM users WHERE email = ? LIMIT 1', 's', [$email]) !== null;
}

function generate_no_pendaftaran()
{
    global $conn;

    $tahun = date('Y');
    $prefix = 'PPDB-' . $tahun . '-%';

    // Gunakan transaksi ringan agar nomor tidak bentrok ketika ada dua submit berdekatan.
    mysqli_begin_transaction($conn);

    $row = db_fetch_one(
        "SELECT no_pendaftaran FROM pendaftaran WHERE no_pendaftaran LIKE ? ORDER BY id DESC LIMIT 1 FOR UPDATE",
        's',
        [$prefix]
    );

    if ($row && !empty($row['no_pendaftaran'])) {
        $last_number = (int) substr($row['no_pendaftaran'], -4);
        $new_number = $last_number + 1;
    } else {
        $new_number = 1;
    }

    mysqli_commit($conn);

    return 'PPDB-' . $tahun . '-' . str_pad($new_number, 4, '0', STR_PAD_LEFT);
}

function format_tanggal($tanggal)
{
    if (empty($tanggal)) {
        return '-';
    }

    $timestamp = strtotime($tanggal);
    if (!$timestamp) {
        return '-';
    }

    $bulan = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
        5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
        9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
    ];

    $hari = date('d', $timestamp);
    $bulan_index = (int) date('m', $timestamp);
    $tahun = date('Y', $timestamp);

    return $hari . ' ' . $bulan[$bulan_index] . ' ' . $tahun;
}

function badge_status($status)
{
    if ($status === 'diterima') {
        return '<span class="status-chip status-chip-diterima"><i class="bi bi-check-circle-fill"></i>Diterima</span>';
    }

    if ($status === 'ditolak') {
        return '<span class="status-chip status-chip-ditolak"><i class="bi bi-x-circle-fill"></i>Ditolak</span>';
    }

    return '<span class="status-chip status-chip-menunggu"><i class="bi bi-hourglass-split"></i>Menunggu Verifikasi</span>';
}
?>
