/* =========================================================
   File: assets/js/app.js
   Sistem PPDB Online MTS SA BINARAHMAH
   MAX UI/UX + Safety Helper
   ========================================================= */

(function () {
    'use strict';

    function ready(callback) {
        if (document.readyState !== 'loading') {
            callback();
        } else {
            document.addEventListener('DOMContentLoaded', callback);
        }
    }

    function rupiahFileSize(bytes) {
        if (!bytes && bytes !== 0) return '-';
        var mb = bytes / (1024 * 1024);
        if (mb >= 1) return mb.toFixed(2) + 'MB';
        return (bytes / 1024).toFixed(0) + 'KB';
    }

    ready(function () {
        document.documentElement.classList.add('js-ready');

        // Bootstrap tooltip
        document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
            if (window.bootstrap && bootstrap.Tooltip) {
                new bootstrap.Tooltip(el);
            }
        });

        // Submit confirmation + loading state tanpa merusak name tombol submit.
        document.querySelectorAll('form').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                var message = form.getAttribute('data-confirm');

                if (message && !window.confirm(message)) {
                    event.preventDefault();
                    return false;
                }

                var submitter = event.submitter || form.querySelector('button[type="submit"]');

                if (submitter && submitter.name && !form.querySelector('input[type="hidden"][name="' + submitter.name + '"]')) {
                    var hidden = document.createElement('input');
                    hidden.type = 'hidden';
                    hidden.name = submitter.name;
                    hidden.value = submitter.value || '1';
                    form.appendChild(hidden);
                }

                if (submitter && !submitter.classList.contains('no-loading')) {
                    submitter.classList.add('btn-loading');
                    submitter.setAttribute('aria-disabled', 'true');
                    submitter.style.pointerEvents = 'none';
                    submitter.innerText = submitter.getAttribute('data-loading-text') || 'Memproses';
                }
            });
        });

        // File preview + early warning di sisi user. Validasi utama tetap di server.
        document.querySelectorAll('input[type="file"]').forEach(function (input) {
            input.addEventListener('change', function () {
                var file = this.files && this.files.length > 0 ? this.files[0] : null;
                var wrapper = this.closest('.upload-card') || this.parentElement;

                if (!wrapper) return;

                var preview = wrapper.querySelector('.selected-file-preview');
                if (!preview) {
                    preview = document.createElement('div');
                    preview.className = 'selected-file-preview mt-2 small fw-semibold';
                    wrapper.appendChild(preview);
                }

                if (!file) {
                    preview.innerHTML = '';
                    return;
                }

                var allowedExt = ['pdf', 'jpg', 'jpeg', 'png'];
                var ext = file.name.split('.').pop().toLowerCase();
                var maxSize = 2 * 1024 * 1024;
                var icon = '<i class="bi bi-paperclip me-1"></i>';

                if (allowedExt.indexOf(ext) === -1) {
                    preview.className = 'selected-file-preview mt-2 small fw-semibold text-danger';
                    preview.innerHTML = '<i class="bi bi-x-circle me-1"></i>Format file tidak diizinkan. Gunakan PDF/JPG/PNG.';
                    return;
                }

                if (file.size > maxSize) {
                    preview.className = 'selected-file-preview mt-2 small fw-semibold text-danger';
                    preview.innerHTML = '<i class="bi bi-exclamation-triangle me-1"></i>' + file.name + ' (' + rupiahFileSize(file.size) + ') melebihi batas 2MB.';
                    return;
                }

                preview.className = 'selected-file-preview mt-2 small fw-semibold text-primary-custom';
                preview.innerHTML = icon + file.name + ' (' + rupiahFileSize(file.size) + ') siap diupload.';
            });
        });

        // Table hint on mobile.
        document.querySelectorAll('.table-responsive').forEach(function (tableWrap) {
            if (!tableWrap.querySelector('.mobile-scroll-hint')) {
                var hint = document.createElement('div');
                hint.className = 'mobile-scroll-hint no-print';
                hint.innerHTML = '<i class="bi bi-arrow-left-right me-1"></i>Geser tabel ke samping untuk melihat data lengkap.';
                tableWrap.insertBefore(hint, tableWrap.firstChild);
            }
        });

        // Smooth reveal untuk elemen utama.
        var revealItems = document.querySelectorAll('.content-card, .info-card, .feature-card, .stat-card, .metric-card, .quick-action-card, .upload-card');

        if ('IntersectionObserver' in window) {
            var observer = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.08 });

            revealItems.forEach(function (item) {
                item.classList.add('ui-reveal');
                observer.observe(item);
            });
        }

        // Back to top button.
        var backTop = document.createElement('button');
        backTop.type = 'button';
        backTop.className = 'back-to-top no-print';
        backTop.setAttribute('aria-label', 'Kembali ke atas');
        backTop.innerHTML = '<i class="bi bi-arrow-up"></i>';
        document.body.appendChild(backTop);

        window.addEventListener('scroll', function () {
            if (window.scrollY > 420) backTop.classList.add('show');
            else backTop.classList.remove('show');
        });

        backTop.addEventListener('click', function () {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });
})();
