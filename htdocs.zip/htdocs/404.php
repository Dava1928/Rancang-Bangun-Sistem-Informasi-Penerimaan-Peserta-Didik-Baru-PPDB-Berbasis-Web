<?php
$page_title = 'Halaman Tidak Ditemukan - PPDB Online MTS SA BINARAHMAH';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>
<section class="error-page"><div class="container"><div class="row justify-content-center text-center"><div class="col-lg-8"><div class="content-card"><div class="error-code mb-3">404</div><div class="empty-state-icon"><i class="bi bi-exclamation-triangle"></i></div><h1 class="fw-bold text-primary-custom mb-3">Halaman Tidak Ditemukan</h1><p class="text-muted mb-4">Maaf, halaman yang Anda cari tidak tersedia, sudah dipindahkan, atau alamat URL tidak sesuai.</p><div class="d-flex flex-wrap justify-content-center gap-2"><a href="<?php echo BASE_URL; ?>index.php" class="btn btn-primary-custom"><i class="bi bi-house-door me-1"></i>Kembali ke Beranda</a><a href="<?php echo BASE_URL; ?>panduan.php" class="btn btn-outline-primary-custom"><i class="bi bi-journal-check me-1"></i>Lihat Panduan</a><a href="<?php echo BASE_URL; ?>kontak.php" class="btn btn-outline-secondary"><i class="bi bi-headset me-1"></i>Hubungi Panitia</a></div></div></div></div></div></section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
