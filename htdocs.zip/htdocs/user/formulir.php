<?php
// =========================================================
// File: user/formulir.php
// Sistem PPDB Online MTS SA BINARAHMAH
// UPDATED: UI/UX modern + validasi upload extension dan MIME type
// =========================================================

$page_title = 'Formulir Pendaftaran - PPDB Online MTS SA BINARAHMAH';

require_once __DIR__ . '/../includes/header.php';
require_user();

$user_id = current_user_id();
$step = isset($_GET['step']) ? (int) $_GET['step'] : 1;
if ($step < 1 || $step > 3) {
    $step = 1;
}

$error = '';

function get_user_pendaftaran($user_id)
{
    return query_single("SELECT * FROM pendaftaran WHERE user_id = '$user_id' LIMIT 1");
}

function get_form_data($pendaftaran_id)
{
    if (!$pendaftaran_id) {
        return [null, null, null];
    }

    $data_pribadi = query_single("SELECT * FROM data_pribadi WHERE pendaftaran_id = '$pendaftaran_id' LIMIT 1");
    $data_orang_tua = query_single("SELECT * FROM data_orang_tua WHERE pendaftaran_id = '$pendaftaran_id' LIMIT 1");
    $dokumen = query_single("SELECT * FROM dokumen WHERE pendaftaran_id = '$pendaftaran_id' LIMIT 1");

    return [$data_pribadi, $data_orang_tua, $dokumen];
}

function detect_file_mime($tmp_name)
{
    $mime = '';

    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = finfo_file($finfo, $tmp_name);
            finfo_close($finfo);
        }
    }

    if (empty($mime) && function_exists('mime_content_type')) {
        $mime = mime_content_type($tmp_name);
    }

    return strtolower((string) $mime);
}

function validate_upload_file($file, $field_label)
{
    $allowed_extensions = ['pdf', 'jpg', 'jpeg', 'png'];
    $allowed_mimes = ['application/pdf', 'image/jpeg', 'image/png'];
    $max_size = 2 * 1024 * 1024;

    if (!isset($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return $field_label . ' wajib diupload.';
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return 'Terjadi kesalahan saat mengupload ' . $field_label . '.';
    }

    if ($file['size'] <= 0) {
        return $field_label . ' tidak valid atau kosong.';
    }

    if ($file['size'] > $max_size) {
        return $field_label . ' maksimal berukuran 2MB.';
    }

    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, $allowed_extensions)) {
        return $field_label . ' harus berupa file PDF, JPG, JPEG, atau PNG.';
    }

    $mime = detect_file_mime($file['tmp_name']);
    if (!in_array($mime, $allowed_mimes)) {
        return $field_label . ' tidak valid. Sistem hanya menerima file PDF, JPG, JPEG, atau PNG asli.';
    }

    if (($extension === 'pdf' && $mime !== 'application/pdf') ||
        (in_array($extension, ['jpg', 'jpeg']) && $mime !== 'image/jpeg') ||
        ($extension === 'png' && $mime !== 'image/png')) {
        return $field_label . ' tidak sesuai antara ekstensi dan tipe file sebenarnya.';
    }

    return '';
}

function upload_file($file, $prefix, $no_pendaftaran = '')
{
    if (!is_dir(UPLOAD_PATH)) {
        mkdir(UPLOAD_PATH, 0755, true);
    }

    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $safe_no = preg_replace('/[^A-Za-z0-9_-]/', '', str_replace('-', '_', $no_pendaftaran));
    $file_name = $prefix . '_' . ($safe_no ? $safe_no . '_' : '') . date('YmdHis') . '_' . bin2hex(random_bytes(4)) . '.' . $extension;
    $target_path = UPLOAD_PATH . $file_name;

    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        return $file_name;
    }

    return false;
}

function delete_old_file($file_name)
{
    if (!empty($file_name)) {
        $file_path = UPLOAD_PATH . $file_name;
        if (file_exists($file_path) && is_file($file_path)) {
            unlink($file_path);
        }
    }
}

$pendaftaran = get_user_pendaftaran($user_id);
$pendaftaran_id = $pendaftaran ? $pendaftaran['id'] : null;
list($data_pribadi, $data_orang_tua, $dokumen) = get_form_data($pendaftaran_id);
$form_locked = $pendaftaran && $pendaftaran['status'] !== 'menunggu';

// =========================================================
// Validasi CSRF untuk seluruh proses POST
// =========================================================

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !verify_csrf_token($_POST['csrf_token'] ?? '')) {
    $error = 'Sesi formulir tidak valid. Silakan muat ulang halaman dan coba lagi.';
}

// =========================================================
// Proses Step 1: Data Pribadi
// =========================================================
if (empty($error) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_step_1'])) {
    if ($form_locked) {
        set_flash('error', 'Formulir tidak dapat diubah karena pendaftaran sudah diverifikasi admin.');
        header('Location: ' . BASE_URL . 'user/formulir.php');
        exit;
    }

    $nama_lengkap = clean_input($_POST['nama_lengkap'] ?? '');
    $nik = clean_input($_POST['nik'] ?? '');
    $nisn = clean_input($_POST['nisn'] ?? '');
    $tempat_lahir = clean_input($_POST['tempat_lahir'] ?? '');
    $tanggal_lahir = clean_input($_POST['tanggal_lahir'] ?? '');
    $jenis_kelamin = clean_input($_POST['jenis_kelamin'] ?? '');
    $agama = clean_input($_POST['agama'] ?? '');
    $alamat = clean_input($_POST['alamat'] ?? '');
    $no_telepon = clean_input($_POST['no_telepon'] ?? '');
    $asal_sekolah = clean_input($_POST['asal_sekolah'] ?? '');

    if (empty($nama_lengkap) || empty($nik) || empty($nisn) || empty($tempat_lahir) || empty($tanggal_lahir) || empty($jenis_kelamin) || empty($agama) || empty($alamat) || empty($no_telepon) || empty($asal_sekolah)) {
        $error = 'Semua field data pribadi wajib diisi.';
    } elseif (strlen($nama_lengkap) < 3) {
        $error = 'Nama lengkap minimal 3 karakter.';
    } elseif (!ctype_digit($nik) || strlen($nik) < 10 || strlen($nik) > 20) {
        $error = 'NIK harus berupa angka dengan panjang 10 sampai 20 digit.';
    } elseif (!ctype_digit($nisn) || strlen($nisn) < 5 || strlen($nisn) > 20) {
        $error = 'NISN harus berupa angka dengan panjang 5 sampai 20 digit.';
    } elseif (!in_array($jenis_kelamin, ['L', 'P'])) {
        $error = 'Jenis kelamin tidak valid.';
    } elseif (!preg_match('/^[0-9+\-\s]{8,15}$/', $no_telepon)) {
        $error = 'Nomor telepon tidak valid.';
    } else {
        if (!$pendaftaran) {
            $no_pendaftaran = generate_no_pendaftaran();
            if (mysqli_query($conn, "INSERT INTO pendaftaran (user_id, no_pendaftaran, status) VALUES ('$user_id', '$no_pendaftaran', 'menunggu')")) {
                $pendaftaran_id = mysqli_insert_id($conn);
            } else {
                $error = 'Gagal membuat data pendaftaran.';
            }
        }

        if (empty($error)) {
            $cek = query_single("SELECT id FROM data_pribadi WHERE pendaftaran_id = '$pendaftaran_id' LIMIT 1");
            if ($cek) {
                $query = "UPDATE data_pribadi SET
                    nama_lengkap = '$nama_lengkap', nik = '$nik', nisn = '$nisn', tempat_lahir = '$tempat_lahir',
                    tanggal_lahir = '$tanggal_lahir', jenis_kelamin = '$jenis_kelamin', agama = '$agama',
                    alamat = '$alamat', no_telepon = '$no_telepon', asal_sekolah = '$asal_sekolah'
                    WHERE pendaftaran_id = '$pendaftaran_id'";
            } else {
                $query = "INSERT INTO data_pribadi (pendaftaran_id, nama_lengkap, nik, nisn, tempat_lahir, tanggal_lahir, jenis_kelamin, agama, alamat, no_telepon, asal_sekolah)
                    VALUES ('$pendaftaran_id', '$nama_lengkap', '$nik', '$nisn', '$tempat_lahir', '$tanggal_lahir', '$jenis_kelamin', '$agama', '$alamat', '$no_telepon', '$asal_sekolah')";
            }

            if (mysqli_query($conn, $query)) {
                set_flash('success', 'Data pribadi berhasil disimpan. Silakan lanjut mengisi data orang tua.');
                header('Location: ' . BASE_URL . 'user/formulir.php?step=2');
                exit;
            } else {
                $error = 'Gagal menyimpan data pribadi.';
            }
        }
    }
}

// =========================================================
// Proses Step 2: Data Orang Tua
// =========================================================
if (empty($error) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_step_2'])) {
    if ($form_locked) {
        set_flash('error', 'Formulir tidak dapat diubah karena pendaftaran sudah diverifikasi admin.');
        header('Location: ' . BASE_URL . 'user/formulir.php');
        exit;
    }

    if (!$pendaftaran_id) {
        set_flash('warning', 'Silakan isi data pribadi terlebih dahulu.');
        header('Location: ' . BASE_URL . 'user/formulir.php?step=1');
        exit;
    }

    $nama_ayah = clean_input($_POST['nama_ayah'] ?? '');
    $pekerjaan_ayah = clean_input($_POST['pekerjaan_ayah'] ?? '');
    $nama_ibu = clean_input($_POST['nama_ibu'] ?? '');
    $pekerjaan_ibu = clean_input($_POST['pekerjaan_ibu'] ?? '');
    $no_telepon_ortu = clean_input($_POST['no_telepon_ortu'] ?? '');
    $penghasilan_ortu = clean_input($_POST['penghasilan_ortu'] ?? '');

    if (empty($nama_ayah) || empty($pekerjaan_ayah) || empty($nama_ibu) || empty($pekerjaan_ibu) || empty($no_telepon_ortu) || empty($penghasilan_ortu)) {
        $error = 'Semua field data orang tua wajib diisi.';
    } elseif (strlen($nama_ayah) < 3 || strlen($nama_ibu) < 3) {
        $error = 'Nama ayah dan ibu minimal 3 karakter.';
    } elseif (!preg_match('/^[0-9+\-\s]{8,15}$/', $no_telepon_ortu)) {
        $error = 'Nomor telepon orang tua tidak valid.';
    } else {
        $cek = query_single("SELECT id FROM data_orang_tua WHERE pendaftaran_id = '$pendaftaran_id' LIMIT 1");
        if ($cek) {
            $query = "UPDATE data_orang_tua SET
                nama_ayah = '$nama_ayah', pekerjaan_ayah = '$pekerjaan_ayah', nama_ibu = '$nama_ibu', pekerjaan_ibu = '$pekerjaan_ibu',
                no_telepon_ortu = '$no_telepon_ortu', penghasilan_ortu = '$penghasilan_ortu'
                WHERE pendaftaran_id = '$pendaftaran_id'";
        } else {
            $query = "INSERT INTO data_orang_tua (pendaftaran_id, nama_ayah, pekerjaan_ayah, nama_ibu, pekerjaan_ibu, no_telepon_ortu, penghasilan_ortu)
                VALUES ('$pendaftaran_id', '$nama_ayah', '$pekerjaan_ayah', '$nama_ibu', '$pekerjaan_ibu', '$no_telepon_ortu', '$penghasilan_ortu')";
        }

        if (mysqli_query($conn, $query)) {
            set_flash('success', 'Data orang tua berhasil disimpan. Silakan lanjut upload dokumen.');
            header('Location: ' . BASE_URL . 'user/formulir.php?step=3');
            exit;
        } else {
            $error = 'Gagal menyimpan data orang tua.';
        }
    }
}

// =========================================================
// Proses Step 3: Upload Dokumen
// =========================================================
if (empty($error) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_step_3'])) {
    if ($form_locked) {
        set_flash('error', 'Formulir tidak dapat diubah karena pendaftaran sudah diverifikasi admin.');
        header('Location: ' . BASE_URL . 'user/formulir.php');
        exit;
    }

    if (!$pendaftaran_id) {
        set_flash('warning', 'Silakan isi data pribadi terlebih dahulu.');
        header('Location: ' . BASE_URL . 'user/formulir.php?step=1');
        exit;
    }

    list($data_pribadi, $data_orang_tua, $dokumen) = get_form_data($pendaftaran_id);
    if (!$data_orang_tua) {
        set_flash('warning', 'Silakan isi data orang tua terlebih dahulu.');
        header('Location: ' . BASE_URL . 'user/formulir.php?step=2');
        exit;
    }

    $existing_dokumen = $dokumen;
    $upload_fields = [
        'foto' => 'Pas Foto',
        'ijazah_sd' => 'Ijazah/STTB SD/MI',
        'akta_kelahiran' => 'Akta Kelahiran',
        'kartu_keluarga' => 'Kartu Keluarga'
    ];

    $uploaded_files = [];
    foreach ($upload_fields as $field_name => $field_label) {
        $is_existing_available = $existing_dokumen && !empty($existing_dokumen[$field_name]);
        $is_new_file_uploaded = isset($_FILES[$field_name]) && $_FILES[$field_name]['error'] !== UPLOAD_ERR_NO_FILE;

        if (!$is_existing_available || $is_new_file_uploaded) {
            $validation_error = validate_upload_file($_FILES[$field_name], $field_label);
            if (!empty($validation_error)) {
                $error = $validation_error;
                break;
            }

            $uploaded_name = upload_file($_FILES[$field_name], $field_name, $pendaftaran['no_pendaftaran'] ?? '');
            if (!$uploaded_name) {
                $error = 'Gagal mengupload ' . $field_label . '.';
                break;
            }
            $uploaded_files[$field_name] = $uploaded_name;
        } else {
            $uploaded_files[$field_name] = $existing_dokumen[$field_name];
        }
    }

    if (empty($error)) {
        if ($existing_dokumen) {
            foreach ($upload_fields as $field_name => $field_label) {
                if (isset($uploaded_files[$field_name]) && $uploaded_files[$field_name] !== $existing_dokumen[$field_name]) {
                    delete_old_file($existing_dokumen[$field_name]);
                }
            }

            $query = "UPDATE dokumen SET
                foto = '{$uploaded_files['foto']}', ijazah_sd = '{$uploaded_files['ijazah_sd']}',
                akta_kelahiran = '{$uploaded_files['akta_kelahiran']}', kartu_keluarga = '{$uploaded_files['kartu_keluarga']}',
                uploaded_at = CURRENT_TIMESTAMP
                WHERE pendaftaran_id = '$pendaftaran_id'";
        } else {
            $query = "INSERT INTO dokumen (pendaftaran_id, foto, ijazah_sd, akta_kelahiran, kartu_keluarga)
                VALUES ('$pendaftaran_id', '{$uploaded_files['foto']}', '{$uploaded_files['ijazah_sd']}', '{$uploaded_files['akta_kelahiran']}', '{$uploaded_files['kartu_keluarga']}')";
        }

        if (mysqli_query($conn, $query)) {
            set_flash('success', 'Dokumen berhasil diupload. Formulir pendaftaran Anda telah lengkap dan menunggu verifikasi admin.');
            header('Location: ' . BASE_URL . 'user/status.php');
            exit;
        } else {
            $error = 'Gagal menyimpan data dokumen.';
        }
    }
}

$pendaftaran = get_user_pendaftaran($user_id);
$pendaftaran_id = $pendaftaran ? $pendaftaran['id'] : null;
list($data_pribadi, $data_orang_tua, $dokumen) = get_form_data($pendaftaran_id);
$form_locked = $pendaftaran && $pendaftaran['status'] !== 'menunggu';

$completed_steps = ($data_pribadi ? 1 : 0) + ($data_orang_tua ? 1 : 0) + ($dokumen ? 1 : 0);
$progress = (int) round(($completed_steps / 3) * 100);

require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="dashboard-wrapper form-page">
    <div class="container">
        <?php echo get_flash(); ?>

        <?php if (!empty($error)) : ?>
            <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0" role="alert">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                <?php echo htmlspecialchars($error); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="form-hero mb-4">
            <div class="row align-items-center g-4">
                <div class="col-lg-8">
                    <span class="hero-kicker">Formulir Multi-Step</span>
                    <h2 class="mb-2">Formulir Pendaftaran PPDB</h2>
                    <p class="mb-0">Lengkapi data pribadi, data orang tua, dan dokumen persyaratan secara bertahap.</p>
                </div>
                <div class="col-lg-4">
                    <div class="form-progress-box">
                        <div class="d-flex justify-content-between mb-2">
                            <span>Kelengkapan</span>
                            <strong><?php echo $progress; ?>%</strong>
                        </div>
                        <div class="progress completion-progress small-progress">
                            <div class="progress-bar" style="width: <?php echo $progress; ?>%;"></div>
                        </div>
                        <?php if ($pendaftaran) : ?>
                            <div class="small mt-2 opacity-75">No. <?php echo htmlspecialchars($pendaftaran['no_pendaftaran']); ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($form_locked) : ?>
            <div class="alert alert-info border-0 shadow-sm">
                <i class="bi bi-lock-fill me-2"></i>
                Formulir tidak dapat diubah karena pendaftaran Anda sudah diverifikasi oleh admin.
            </div>
        <?php endif; ?>

        <div class="content-card form-card-modern">
            <div class="stepper modern-stepper">
                <div class="step-item <?php echo ($step == 1) ? 'active' : ''; ?> <?php echo ($data_pribadi) ? 'completed' : ''; ?>">
                    <a href="<?php echo BASE_URL; ?>user/formulir.php?step=1">
                        <div class="step-number">1</div>
                        <div class="step-label">Data Pribadi</div>
                    </a>
                </div>
                <div class="step-item <?php echo ($step == 2) ? 'active' : ''; ?> <?php echo ($data_orang_tua) ? 'completed' : ''; ?>">
                    <a href="<?php echo BASE_URL; ?>user/formulir.php?step=2">
                        <div class="step-number">2</div>
                        <div class="step-label">Data Orang Tua</div>
                    </a>
                </div>
                <div class="step-item <?php echo ($step == 3) ? 'active' : ''; ?> <?php echo ($dokumen) ? 'completed' : ''; ?>">
                    <a href="<?php echo BASE_URL; ?>user/formulir.php?step=3">
                        <div class="step-number">3</div>
                        <div class="step-label">Upload Dokumen</div>
                    </a>
                </div>
            </div>

            <?php if ($step == 1) : ?>
                <div class="form-section-title">
                    <div class="section-icon"><i class="bi bi-person-lines-fill"></i></div>
                    <div>
                        <h4>Step 1 - Data Pribadi Calon Peserta Didik</h4>
                        <p>Pastikan data sesuai dengan dokumen resmi calon peserta didik.</p>
                    </div>
                </div>

                <form action="<?php echo BASE_URL; ?>user/formulir.php?step=1" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3">
                        <div class="col-md-12">
                            <label class="form-label required">Nama Lengkap</label>
                            <input type="text" name="nama_lengkap" class="form-control" value="<?php echo htmlspecialchars($data_pribadi['nama_lengkap'] ?? current_user_name()); ?>" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">NIK</label>
                            <input type="text" name="nik" class="form-control" value="<?php echo htmlspecialchars($data_pribadi['nik'] ?? ''); ?>" maxlength="20" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">NISN</label>
                            <input type="text" name="nisn" class="form-control" value="<?php echo htmlspecialchars($data_pribadi['nisn'] ?? ''); ?>" maxlength="20" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">Tempat Lahir</label>
                            <input type="text" name="tempat_lahir" class="form-control" value="<?php echo htmlspecialchars($data_pribadi['tempat_lahir'] ?? ''); ?>" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">Tanggal Lahir</label>
                            <input type="date" name="tanggal_lahir" class="form-control" value="<?php echo htmlspecialchars($data_pribadi['tanggal_lahir'] ?? ''); ?>" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">Jenis Kelamin</label>
                            <select name="jenis_kelamin" class="form-select" required <?php echo $form_locked ? 'disabled' : ''; ?>>
                                <option value="">-- Pilih Jenis Kelamin --</option>
                                <option value="L" <?php echo (($data_pribadi['jenis_kelamin'] ?? '') == 'L') ? 'selected' : ''; ?>>Laki-laki</option>
                                <option value="P" <?php echo (($data_pribadi['jenis_kelamin'] ?? '') == 'P') ? 'selected' : ''; ?>>Perempuan</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">Agama</label>
                            <input type="text" name="agama" class="form-control" value="<?php echo htmlspecialchars($data_pribadi['agama'] ?? 'Islam'); ?>" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                        </div>
                        <div class="col-md-12">
                            <label class="form-label required">Alamat Lengkap</label>
                            <textarea name="alamat" rows="4" class="form-control" required <?php echo $form_locked ? 'readonly' : ''; ?>><?php echo htmlspecialchars($data_pribadi['alamat'] ?? ''); ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">Nomor Telepon</label>
                            <input type="text" name="no_telepon" class="form-control" value="<?php echo htmlspecialchars($data_pribadi['no_telepon'] ?? ''); ?>" maxlength="15" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label required">Asal Sekolah SD/MI</label>
                            <input type="text" name="asal_sekolah" class="form-control" value="<?php echo htmlspecialchars($data_pribadi['asal_sekolah'] ?? ''); ?>" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                        </div>
                    </div>

                    <div class="d-flex justify-content-end mt-4">
                        <?php if (!$form_locked) : ?>
                            <button type="submit" name="submit_step_1" class="btn btn-primary-custom">Simpan dan Lanjut <i class="bi bi-arrow-right ms-1"></i></button>
                        <?php else : ?>
                            <a href="<?php echo BASE_URL; ?>user/formulir.php?step=2" class="btn btn-primary-custom">Lanjut <i class="bi bi-arrow-right ms-1"></i></a>
                        <?php endif; ?>
                    </div>
                </form>

            <?php elseif ($step == 2) : ?>
                <?php if (!$data_pribadi) : ?>
                    <div class="alert alert-warning border-0 shadow-sm">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        Silakan isi data pribadi terlebih dahulu.
                        <a href="<?php echo BASE_URL; ?>user/formulir.php?step=1" class="btn btn-sm btn-primary-custom ms-2">Isi Data Pribadi</a>
                    </div>
                <?php else : ?>
                    <div class="form-section-title">
                        <div class="section-icon"><i class="bi bi-people-fill"></i></div>
                        <div>
                            <h4>Step 2 - Data Orang Tua / Wali</h4>
                            <p>Data ini digunakan panitia untuk kebutuhan administrasi dan komunikasi.</p>
                        </div>
                    </div>

                    <form action="<?php echo BASE_URL; ?>user/formulir.php?step=2" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label required">Nama Ayah</label>
                                <input type="text" name="nama_ayah" class="form-control" value="<?php echo htmlspecialchars($data_orang_tua['nama_ayah'] ?? ''); ?>" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label required">Pekerjaan Ayah</label>
                                <input type="text" name="pekerjaan_ayah" class="form-control" value="<?php echo htmlspecialchars($data_orang_tua['pekerjaan_ayah'] ?? ''); ?>" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label required">Nama Ibu</label>
                                <input type="text" name="nama_ibu" class="form-control" value="<?php echo htmlspecialchars($data_orang_tua['nama_ibu'] ?? ''); ?>" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label required">Pekerjaan Ibu</label>
                                <input type="text" name="pekerjaan_ibu" class="form-control" value="<?php echo htmlspecialchars($data_orang_tua['pekerjaan_ibu'] ?? ''); ?>" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label required">Nomor Telepon Orang Tua</label>
                                <input type="text" name="no_telepon_ortu" class="form-control" value="<?php echo htmlspecialchars($data_orang_tua['no_telepon_ortu'] ?? ''); ?>" maxlength="15" required <?php echo $form_locked ? 'readonly' : ''; ?>>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label required">Penghasilan Orang Tua</label>
                                <select name="penghasilan_ortu" class="form-select" required <?php echo $form_locked ? 'disabled' : ''; ?>>
                                    <option value="">-- Pilih Penghasilan --</option>
                                    <?php foreach (['< Rp1.000.000', 'Rp1.000.000 - Rp2.500.000', 'Rp2.500.000 - Rp5.000.000', '> Rp5.000.000'] as $opt) : ?>
                                        <option value="<?php echo htmlspecialchars($opt); ?>" <?php echo (($data_orang_tua['penghasilan_ortu'] ?? '') == $opt) ? 'selected' : ''; ?>><?php echo htmlspecialchars($opt); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between mt-4">
                            <a href="<?php echo BASE_URL; ?>user/formulir.php?step=1" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Kembali</a>
                            <?php if (!$form_locked) : ?>
                                <button type="submit" name="submit_step_2" class="btn btn-primary-custom">Simpan dan Lanjut <i class="bi bi-arrow-right ms-1"></i></button>
                            <?php else : ?>
                                <a href="<?php echo BASE_URL; ?>user/formulir.php?step=3" class="btn btn-primary-custom">Lanjut <i class="bi bi-arrow-right ms-1"></i></a>
                            <?php endif; ?>
                        </div>
                    </form>
                <?php endif; ?>

            <?php else : ?>
                <?php if (!$data_pribadi || !$data_orang_tua) : ?>
                    <div class="alert alert-warning border-0 shadow-sm">
                        <i class="bi bi-exclamation-triangle-fill me-2"></i>
                        Silakan lengkapi data pribadi dan data orang tua terlebih dahulu.
                    </div>
                <?php else : ?>
                    <div class="form-section-title">
                        <div class="section-icon"><i class="bi bi-file-earmark-arrow-up-fill"></i></div>
                        <div>
                            <h4>Step 3 - Upload Dokumen Persyaratan</h4>
                            <p>Upload dokumen asli dengan format PDF, JPG, JPEG, atau PNG. Ukuran maksimal setiap file 2MB.</p>
                        </div>
                    </div>

                    <div class="secure-note mb-4">
                        <i class="bi bi-shield-check"></i>
                        <div>
                            <strong>Validasi keamanan aktif.</strong>
                            File dicek berdasarkan ekstensi dan MIME type agar dokumen yang diunggah lebih aman.
                        </div>
                    </div>

                    <form action="<?php echo BASE_URL; ?>user/formulir.php?step=3" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row g-3">
                            <?php foreach (['foto' => 'Pas Foto', 'ijazah_sd' => 'Ijazah/STTB SD/MI', 'akta_kelahiran' => 'Akta Kelahiran', 'kartu_keluarga' => 'Kartu Keluarga'] as $name => $label) : ?>
                                <div class="col-md-6">
                                    <div class="upload-card">
                                        <label class="form-label required"><?php echo $label; ?></label>
                                        <input type="file" name="<?php echo $name; ?>" class="form-control" accept=".pdf,.jpg,.jpeg,.png" <?php echo (!$dokumen || empty($dokumen[$name])) ? 'required' : ''; ?> <?php echo $form_locked ? 'disabled' : ''; ?>>
                                        <small class="text-muted d-block mt-2">PDF/JPG/PNG, maksimal 2MB.</small>
                                        <?php if ($dokumen && !empty($dokumen[$name])) : ?>
                                            <div class="mt-3">
                                                <a href="<?php echo secure_document_url($pendaftaran_id, $name); ?>" target="_blank" class="document-link">
                                                    <i class="bi bi-eye me-1"></i>Lihat File Saat Ini
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>

                        <?php if ($dokumen && !$form_locked) : ?>
                            <div class="alert alert-warning border-0 shadow-sm mt-4">
                                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                                Jika memilih file baru, file lama akan diganti. Kosongkan input file jika tidak ingin mengganti dokumen.
                            </div>
                        <?php endif; ?>

                        <div class="d-flex justify-content-between mt-4">
                            <a href="<?php echo BASE_URL; ?>user/formulir.php?step=2" class="btn btn-outline-secondary"><i class="bi bi-arrow-left me-1"></i>Kembali</a>
                            <?php if (!$form_locked) : ?>
                                <button type="submit" name="submit_step_3" class="btn btn-primary-custom"><i class="bi bi-upload me-1"></i>Simpan Dokumen</button>
                            <?php else : ?>
                                <a href="<?php echo BASE_URL; ?>user/status.php" class="btn btn-primary-custom">Lihat Status <i class="bi bi-arrow-right ms-1"></i></a>
                            <?php endif; ?>
                        </div>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
