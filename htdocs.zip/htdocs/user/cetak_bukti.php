<?php
// =========================================================
// File: user/cetak_bukti.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Halaman cetak bukti pendaftaran (print mode browser)
// =========================================================

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_user();

$user_id = current_user_id();

$pendaftaran = query_single(
    "SELECT p.no_pendaftaran, p.status, p.catatan_admin, p.tanggal_daftar,
            dp.nama_lengkap, dp.nisn, dp.nik, dp.tempat_lahir, dp.tanggal_lahir,
            dp.jenis_kelamin, dp.agama, dp.asal_sekolah, dp.alamat, dp.no_telepon,
            dot.nama_ayah, dot.nama_ibu, dot.no_telepon_ortu
     FROM pendaftaran p
     LEFT JOIN data_pribadi dp ON p.id = dp.pendaftaran_id
     LEFT JOIN data_orang_tua dot ON p.id = dot.pendaftaran_id
     WHERE p.user_id = '$user_id'
     LIMIT 1"
);

if (!$pendaftaran) {
    set_flash('error', 'Anda belum memiliki data pendaftaran.');
    header('Location: ' . BASE_URL . 'user/dashboard.php');
    exit;
}

$status_label = [
    'menunggu' => 'Menunggu Verifikasi',
    'diterima' => 'DITERIMA',
    'ditolak'  => 'Ditolak',
];
$status_color = [
    'menunggu' => '#e67e22',
    'diterima' => '#27ae60',
    'ditolak'  => '#e74c3c',
];
$st = $pendaftaran['status'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bukti Pendaftaran PPDB - <?= htmlspecialchars($pendaftaran['no_pendaftaran']) ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 12pt;
            color: #000;
            background: #f0f0f0;
        }

        /* Wrapper layar (non-print) */
        .screen-wrapper {
            max-width: 800px;
            margin: 30px auto;
            background: white;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            border-radius: 4px;
        }

        /* Tombol aksi (hanya layar) */
        .action-bar {
            background: #1a5276;
            padding: 14px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 4px 4px 0 0;
        }
        .action-bar span { color: white; font-family: Arial, sans-serif; font-size: 13px; }
        .btn-print {
            background: white;
            color: #1a5276;
            border: none;
            padding: 8px 20px;
            border-radius: 6px;
            font-weight: 700;
            font-family: Arial, sans-serif;
            font-size: 13px;
            cursor: pointer;
        }
        .btn-back {
            color: rgba(255,255,255,0.85);
            text-decoration: none;
            font-family: Arial, sans-serif;
            font-size: 13px;
        }

        /* Dokumen cetak */
        .dokumen {
            padding: 30px 40px;
        }

        /* Kop surat */
        .kop {
            border-bottom: 3px solid #1a5276;
            padding-bottom: 12px;
            margin-bottom: 20px;
        }
        .kop-table { width: 100%; border-collapse: collapse; }
        .kop-logo {
            width: 70px;
            text-align: center;
            vertical-align: middle;
        }
        .kop-logo .logo-box {
            width: 60px;
            height: 60px;
            border: 2px solid #1a5276;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24pt;
            color: #1a5276;
            margin: auto;
        }
        .kop-text { vertical-align: middle; padding-left: 15px; }
        .kop-text h2 {
            font-size: 14pt;
            color: #1a5276;
            font-weight: bold;
            text-transform: uppercase;
            margin-bottom: 2px;
        }
        .kop-text p {
            font-size: 9pt;
            color: #444;
            margin-bottom: 1px;
        }

        /* Judul bukti */
        .judul-bukti {
            text-align: center;
            margin: 16px 0 14px;
        }
        .judul-bukti h3 {
            font-size: 13pt;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #1a5276;
        }
        .judul-bukti .garis {
            height: 2px;
            background: #1a5276;
            margin: 4px auto 0;
            width: 60%;
        }

        /* Badge status besar */
        .status-banner {
            text-align: center;
            margin: 14px 0;
            padding: 12px;
            border-radius: 6px;
            border: 2px solid <?= $status_color[$st] ?? '#888' ?>;
            background: <?= $st === 'diterima' ? '#eafaf1' : ($st === 'ditolak' ? '#fdf0f0' : '#fef9f0') ?>;
        }
        .status-banner .label-status {
            font-size: 16pt;
            font-weight: bold;
            color: <?= $status_color[$st] ?? '#888' ?>;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .status-banner .no-pendaftaran {
            font-size: 13pt;
            font-weight: bold;
            color: #1a5276;
            margin-top: 4px;
        }

        /* Tabel data */
        .section-title {
            font-size: 10pt;
            font-weight: bold;
            background: #1a5276;
            color: white;
            padding: 5px 10px;
            margin-top: 14px;
            margin-bottom: 0;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 6px;
        }
        .data-table tr td {
            border: 1px solid #bbb;
            padding: 5px 10px;
            font-size: 10pt;
            vertical-align: top;
        }
        .data-table tr td:first-child {
            width: 200px;
            font-weight: bold;
            background: #f5f5f5;
            color: #222;
        }

        /* Catatan admin */
        .catatan-box {
            border: 1px solid #e74c3c;
            background: #fdf0f0;
            padding: 8px 12px;
            border-radius: 4px;
            font-size: 10pt;
            margin-top: 10px;
        }

        /* Tanda tangan */
        .ttd-section {
            margin-top: 24px;
            display: flex;
            justify-content: space-between;
        }
        .ttd-box { text-align: center; width: 200px; }
        .ttd-box .ttd-line {
            border-bottom: 1px solid #333;
            height: 60px;
            margin-bottom: 4px;
        }
        .ttd-box p { font-size: 9pt; }

        /* Footer dokumen */
        .footer-doc {
            margin-top: 16px;
            padding-top: 8px;
            border-top: 1px dashed #aaa;
            font-size: 8pt;
            color: #666;
            text-align: center;
        }

        /* Print CSS */
        @media print {
            body { background: white !important; }
            .screen-wrapper {
                box-shadow: none !important;
                margin: 0 !important;
                border-radius: 0 !important;
            }
            .action-bar { display: none !important; }
            .dokumen { padding: 20px !important; }
        }

        @page {
            size: A4;
            margin: 1.5cm;
        }
    </style>
</head>
<body>

<div class="screen-wrapper">

    <!-- Action bar (hanya muncul di layar, tidak tercetak) -->
    <div class="action-bar">
        <a href="<?= BASE_URL ?>user/status.php" class="btn-back">
            ← Kembali ke Status
        </a>
        <span>Pratinjau Bukti Pendaftaran</span>
        <button class="btn-print" onclick="window.print()">🖨️ Cetak / Simpan PDF</button>
    </div>

    <!-- Dokumen yang akan dicetak -->
    <div class="dokumen">

        <!-- KOP SURAT -->
        <div class="kop">
            <table class="kop-table">
                <tr>
                    <td class="kop-logo">
                        <div class="logo-box">🏫</div>
                    </td>
                    <td class="kop-text">
                        <h2>Madrasah Tsanawiyah Swasta Binarahmah</h2>
                        <p>Jl. Binarahmah No. 1, Bandung, Jawa Barat</p>
                        <p>Email: ppdb@binarahmah.sch.id &nbsp;|&nbsp; Website: binarahmah.sch.id</p>
                        <p>Terakreditasi oleh Kementerian Agama Republik Indonesia</p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- JUDUL -->
        <div class="judul-bukti">
            <h3>Bukti Pendaftaran PPDB Online</h3>
            <h3>Tahun Ajaran <?= date('Y') ?>/<?= date('Y') + 1 ?></h3>
            <div class="garis"></div>
        </div>

        <!-- STATUS BANNER -->
        <div class="status-banner">
            <div class="label-status">
                <?= ($st === 'menunggu') ? '⏳ ' : ($st === 'diterima' ? '✅ ' : '❌ ') ?>
                <?= htmlspecialchars($status_label[$st] ?? ucfirst($st)) ?>
            </div>
            <div class="no-pendaftaran">
                Nomor Pendaftaran: <?= htmlspecialchars($pendaftaran['no_pendaftaran']) ?>
            </div>
            <div style="font-size:9pt; color:#555; margin-top:2px;">
                Tanggal Daftar: <?= format_tanggal($pendaftaran['tanggal_daftar']) ?>
            </div>
        </div>

        <!-- DATA PRIBADI -->
        <div class="section-title">A. Data Calon Peserta Didik</div>
        <table class="data-table">
            <tr><td>Nama Lengkap</td><td><?= htmlspecialchars($pendaftaran['nama_lengkap'] ?? '-') ?></td></tr>
            <tr><td>NISN</td><td><?= htmlspecialchars($pendaftaran['nisn'] ?? '-') ?></td></tr>
            <tr>
                <td>Tempat, Tanggal Lahir</td>
                <td>
                    <?= htmlspecialchars($pendaftaran['tempat_lahir'] ?? '-') ?>,
                    <?= !empty($pendaftaran['tanggal_lahir']) ? format_tanggal($pendaftaran['tanggal_lahir']) : '-' ?>
                </td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td><?= ($pendaftaran['jenis_kelamin'] === 'L') ? 'Laki-laki' : (($pendaftaran['jenis_kelamin'] === 'P') ? 'Perempuan' : '-') ?></td>
            </tr>
            <tr><td>Agama</td><td><?= htmlspecialchars($pendaftaran['agama'] ?? '-') ?></td></tr>
            <tr><td>Asal Sekolah (SD/MI)</td><td><?= htmlspecialchars($pendaftaran['asal_sekolah'] ?? '-') ?></td></tr>
            <tr><td>Alamat</td><td><?= nl2br(htmlspecialchars($pendaftaran['alamat'] ?? '-')) ?></td></tr>
            <tr><td>Nomor Telepon</td><td><?= htmlspecialchars($pendaftaran['no_telepon'] ?? '-') ?></td></tr>
        </table>

        <!-- DATA ORANG TUA -->
        <div class="section-title">B. Data Orang Tua / Wali</div>
        <table class="data-table">
            <tr><td>Nama Ayah</td><td><?= htmlspecialchars($pendaftaran['nama_ayah'] ?? '-') ?></td></tr>
            <tr><td>Nama Ibu</td><td><?= htmlspecialchars($pendaftaran['nama_ibu'] ?? '-') ?></td></tr>
            <tr><td>Nomor Telepon Orang Tua</td><td><?= htmlspecialchars($pendaftaran['no_telepon_ortu'] ?? '-') ?></td></tr>
        </table>

        <!-- INFO PENDAFTARAN -->
        <div class="section-title">C. Informasi Pendaftaran</div>
        <table class="data-table">
            <tr><td>Nomor Pendaftaran</td><td><strong><?= htmlspecialchars($pendaftaran['no_pendaftaran']) ?></strong></td></tr>
            <tr><td>Tanggal Mendaftar</td><td><?= format_tanggal($pendaftaran['tanggal_daftar']) ?></td></tr>
            <tr>
                <td>Status Pendaftaran</td>
                <td><strong style="color:<?= $status_color[$st] ?? '#333' ?>; text-transform:uppercase;">
                    <?= htmlspecialchars($status_label[$st] ?? ucfirst($st)) ?>
                </strong></td>
            </tr>
        </table>

        <!-- CATATAN ADMIN (jika ada) -->
        <?php if (!empty($pendaftaran['catatan_admin'])) : ?>
            <div class="catatan-box">
                <strong>📝 Catatan dari Panitia PPDB:</strong><br>
                <?= nl2br(htmlspecialchars($pendaftaran['catatan_admin'])) ?>
            </div>
        <?php endif; ?>

        <!-- TANDA TANGAN -->
        <div class="ttd-section">
            <div class="ttd-box">
                <p>Calon Peserta Didik,</p>
                <div class="ttd-line"></div>
                <p><strong><?= htmlspecialchars($pendaftaran['nama_lengkap'] ?? '.....................') ?></strong></p>
            </div>
            <div class="ttd-box">
                <p>Panitia PPDB MTS SA BINARAHMAH,</p>
                <div class="ttd-line"></div>
                <p><strong>(..................................)</strong></p>
                <p style="font-size:8pt;">NIP/NIK: ...</p>
            </div>
        </div>

        <!-- FOOTER DOKUMEN -->
        <div class="footer-doc">
            Bukti ini dicetak secara otomatis melalui Sistem PPDB Online MTS SA BINARAHMAH &nbsp;|&nbsp;
            Dicetak pada: <?= date('d F Y, H:i') ?> WIB &nbsp;|&nbsp;
            Dokumen ini sah tanpa tanda tangan dan stempel apabila diunduh langsung dari sistem PPDB Online.
        </div>

    </div><!-- /dokumen -->
</div><!-- /screen-wrapper -->

<script>
    // Auto print jika ada parameter ?print=1
    const params = new URLSearchParams(window.location.search);
    if (params.get('print') === '1') {
        window.addEventListener('load', () => window.print());
    }
</script>
</body>
</html>
