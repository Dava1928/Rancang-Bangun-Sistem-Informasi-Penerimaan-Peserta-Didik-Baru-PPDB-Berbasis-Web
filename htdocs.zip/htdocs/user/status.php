<?php
// =========================================================
// File: user/status.php - UPDATED: tombol cetak bukti
// =========================================================
$page_title = 'Status Pendaftaran - PPDB Online MTS SA BINARAHMAH';
require_once __DIR__ . '/../includes/header.php';
require_user();
$user_id = current_user_id();
$pendaftaran = query_single("SELECT p.*, dp.nama_lengkap AS nama_calon, dp.nik, dp.nisn, dp.tempat_lahir, dp.tanggal_lahir, dp.jenis_kelamin, dp.agama, dp.alamat, dp.no_telepon, dp.asal_sekolah, dot.nama_ayah, dot.pekerjaan_ayah, dot.nama_ibu, dot.pekerjaan_ibu, dot.no_telepon_ortu, dot.penghasilan_ortu, d.foto, d.ijazah_sd, d.akta_kelahiran, d.kartu_keluarga, d.uploaded_at FROM pendaftaran p LEFT JOIN data_pribadi dp ON p.id = dp.pendaftaran_id LEFT JOIN data_orang_tua dot ON p.id = dot.pendaftaran_id LEFT JOIN dokumen d ON p.id = d.pendaftaran_id WHERE p.user_id = '$user_id' LIMIT 1");
require_once __DIR__ . '/../includes/navbar.php';
?>
<div class="dashboard-wrapper"><div class="container"><?php echo get_flash(); ?>
<div class="row align-items-center mb-4">
    <div class="col-md-7"><h2 class="page-title">Status Pendaftaran</h2><p class="page-subtitle mb-md-0">Pantau status pendaftaran PPDB Online MTS SA BINARAHMAH Anda.</p></div>
    <div class="col-md-5 text-md-end no-print d-flex flex-wrap justify-content-md-end gap-2 mt-2 mt-md-0">
        <?php if ($pendaftaran) : ?>
        <a href="<?php echo BASE_URL; ?>user/cetak_bukti.php" target="_blank"
           class="btn btn-sm fw-bold"
           style="background:linear-gradient(135deg,#1e8449,#27ae60);color:white;border:none;border-radius:8px;padding:8px 16px;">
            <i class="bi bi-printer-fill me-1"></i>Cetak Bukti Pendaftaran
        </a>
        <?php endif; ?>
        <a href="<?php echo BASE_URL; ?>user/dashboard.php" class="btn btn-sm btn-outline-primary-custom">
            <i class="bi bi-arrow-left me-1"></i>Dashboard
        </a>
    </div>
</div>

<?php if (!$pendaftaran) : ?>
<div class="content-card"><div class="empty-state"><i class="bi bi-file-earmark-x text-primary-custom" style="font-size:4rem;"></i><h5 class="mt-3">Belum Ada Data Pendaftaran</h5><p>Anda belum mengisi formulir pendaftaran. Silakan lengkapi formulir terlebih dahulu.</p><a href="<?php echo BASE_URL; ?>user/formulir.php" class="btn btn-primary-custom"><i class="bi bi-pencil-square me-1"></i>Isi Formulir</a></div></div>

<?php else : ?>
<?php
$status_class='status-menunggu'; $status_icon='bi-hourglass-split'; $status_title='Menunggu Verifikasi'; $status_message='Data pendaftaran Anda sedang menunggu proses verifikasi oleh admin PPDB.';
if ($pendaftaran['status']==='diterima'){ $status_class='status-diterima'; $status_icon='bi-check-circle-fill'; $status_title='Pendaftaran Diterima'; $status_message='Selamat, pendaftaran Anda telah diterima. Silakan mengikuti informasi daftar ulang dari pihak madrasah.'; }
elseif ($pendaftaran['status']==='ditolak'){ $status_class='status-ditolak'; $status_icon='bi-x-circle-fill'; $status_title='Pendaftaran Ditolak'; $status_message='Mohon periksa catatan dari admin untuk mengetahui alasan penolakan pendaftaran.'; }
?>
<div class="status-box text-center mb-4">
    <div class="status-icon <?php echo $status_class; ?>"><i class="bi <?php echo $status_icon; ?>"></i></div>
    <h3 class="fw-bold text-primary-custom mb-2"><?php echo $status_title; ?></h3>
    <p class="text-muted mb-3"><?php echo $status_message; ?></p>
    <div class="mb-3"><?php echo badge_status($pendaftaran['status']); ?></div>
    <h5 class="fw-bold mb-0">Nomor Pendaftaran: <span class="text-primary-custom"><?php echo htmlspecialchars($pendaftaran['no_pendaftaran']); ?></span></h5>
    <?php if (!empty($pendaftaran['catatan_admin'])) : ?><div class="alert alert-info mt-4 mb-0 text-start"><strong><i class="bi bi-chat-left-text-fill me-1"></i>Catatan Admin:</strong><br><?php echo nl2br(htmlspecialchars($pendaftaran['catatan_admin'])); ?></div><?php endif; ?>
    <?php if ($pendaftaran['status'] === 'diterima') : ?>
    <div class="mt-4 p-3 no-print" style="background:#eafaf1;border:2px solid #27ae60;border-radius:10px;">
        <p class="mb-2" style="color:#1e8449;font-weight:600;">🎉 Selamat! Anda diterima. Unduh dan simpan bukti pendaftaran Anda.</p>
        <a href="<?php echo BASE_URL; ?>user/cetak_bukti.php" target="_blank" class="btn btn-success fw-bold" style="border-radius:8px;">
            <i class="bi bi-printer-fill me-2"></i>Cetak / Unduh Bukti Pendaftaran
        </a>
    </div>
    <?php endif; ?>
</div>

<div class="content-card print-area">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div><h4 class="mb-1"><i class="bi bi-card-checklist me-2"></i>Detail Pendaftaran</h4><p class="text-muted mb-0">Data lengkap pendaftaran calon peserta didik.</p></div>
        <div class="no-print d-flex gap-2">
            <a href="<?php echo BASE_URL; ?>user/cetak_bukti.php" target="_blank"
               class="btn btn-success btn-sm fw-bold" style="border-radius:8px;">
                <i class="bi bi-printer-fill me-1"></i>Cetak Bukti
            </a>
            <button type="button" onclick="window.print()" class="btn btn-primary-custom btn-sm">
                <i class="bi bi-printer me-1"></i>Print Halaman
            </button>
        </div>
    </div>
    <?php $sections=[ 'A. Informasi Pendaftaran'=>['Nomor Pendaftaran'=>$pendaftaran['no_pendaftaran'],'Tanggal Daftar'=>format_tanggal($pendaftaran['tanggal_daftar']),'Status'=>badge_status($pendaftaran['status'])], 'B. Data Pribadi Calon Peserta Didik'=>['Nama Lengkap'=>$pendaftaran['nama_calon'] ?? '-','NIK'=>$pendaftaran['nik'] ?? '-','NISN'=>$pendaftaran['nisn'] ?? '-','Tempat, Tanggal Lahir'=>($pendaftaran['tempat_lahir'] ?? '-') . ', ' . (!empty($pendaftaran['tanggal_lahir']) ? format_tanggal($pendaftaran['tanggal_lahir']) : '-'),'Jenis Kelamin'=>(($pendaftaran['jenis_kelamin'] ?? '')==='L'?'Laki-laki':((($pendaftaran['jenis_kelamin'] ?? '')==='P')?'Perempuan':'-')),'Agama'=>$pendaftaran['agama'] ?? '-','Alamat'=>nl2br(htmlspecialchars($pendaftaran['alamat'] ?? '-')),'Nomor Telepon'=>$pendaftaran['no_telepon'] ?? '-','Asal Sekolah'=>$pendaftaran['asal_sekolah'] ?? '-'], 'C. Data Orang Tua / Wali'=>['Nama Ayah'=>$pendaftaran['nama_ayah'] ?? '-','Pekerjaan Ayah'=>$pendaftaran['pekerjaan_ayah'] ?? '-','Nama Ibu'=>$pendaftaran['nama_ibu'] ?? '-','Pekerjaan Ibu'=>$pendaftaran['pekerjaan_ibu'] ?? '-','Nomor Telepon Orang Tua'=>$pendaftaran['no_telepon_ortu'] ?? '-','Penghasilan Orang Tua'=>$pendaftaran['penghasilan_ortu'] ?? '-'] ]; foreach($sections as $title=>$rows): ?><h5 class="mb-3"><?php echo $title; ?></h5><div class="table-responsive mb-4"><table class="table table-bordered"><?php foreach($rows as $k=>$v): ?><tr><th style="width:260px;"><?php echo $k; ?></th><td><?php echo $v; ?></td></tr><?php endforeach; ?></table></div><?php endforeach; ?>
    <h5 class="mb-3">D. Dokumen Persyaratan</h5><div class="table-responsive"><table class="table table-bordered"><?php foreach(['foto'=>'Pas Foto','ijazah_sd'=>'Ijazah/STTB SD/MI','akta_kelahiran'=>'Akta Kelahiran','kartu_keluarga'=>'Kartu Keluarga'] as $f=>$label): ?><tr><th style="width:260px;"><?php echo $label; ?></th><td><?php if(!empty($pendaftaran[$f])): ?><a href="<?php echo secure_document_url($pendaftaran['id'], $f); ?>" target="_blank" class="document-link no-print"><i class="bi bi-eye me-1"></i>Lihat Dokumen</a><span class="d-none d-print-inline"><?php echo htmlspecialchars($pendaftaran[$f]); ?></span><?php else: ?>-<?php endif; ?></td></tr><?php endforeach; ?><tr><th>Tanggal Upload</th><td><?php echo !empty($pendaftaran['uploaded_at']) ? format_tanggal($pendaftaran['uploaded_at']) : '-'; ?></td></tr></table></div>
    <div class="mt-4 no-print d-flex flex-wrap gap-2">
        <a href="<?php echo BASE_URL; ?>user/formulir.php" class="btn btn-outline-primary-custom"><i class="bi bi-pencil-square me-1"></i>Lihat Formulir</a>
        <a href="<?php echo BASE_URL; ?>user/cetak_bukti.php" target="_blank" class="btn btn-success fw-bold" style="border-radius:8px;border:none;background:linear-gradient(135deg,#1e8449,#27ae60);"><i class="bi bi-printer-fill me-1"></i>Cetak Bukti Pendaftaran</a>
    </div>
</div>
<?php endif; ?>
</div></div>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
