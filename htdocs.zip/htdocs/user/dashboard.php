<?php
// =========================================================
// File: user/dashboard.php
// Sistem PPDB Online MTS SA BINARAHMAH
// UPDATED: progress kelengkapan + UI/UX dashboard user
// =========================================================

$page_title = 'Dashboard User - PPDB Online MTS SA BINARAHMAH';

require_once __DIR__ . '/../includes/header.php';
require_user();

$user_id = current_user_id();

$pendaftaran = query_single("
    SELECT
        p.*,
        dp.nama_lengkap AS nama_calon,
        dp.nik,
        dp.nisn,
        dp.asal_sekolah,
        dot.id AS orang_tua_id,
        d.id AS dokumen_id,
        d.foto,
        d.ijazah_sd,
        d.akta_kelahiran,
        d.kartu_keluarga
    FROM pendaftaran p
    LEFT JOIN data_pribadi dp ON p.id = dp.pendaftaran_id
    LEFT JOIN data_orang_tua dot ON p.id = dot.pendaftaran_id
    LEFT JOIN dokumen d ON p.id = d.pendaftaran_id
    WHERE p.user_id = '$user_id'
    LIMIT 1
");

$progress = 0;
$completed_steps = 0;
$is_data_pribadi_complete = false;
$is_data_orang_tua_complete = false;
$is_dokumen_complete = false;
$is_locked = false;
$next_action_url = BASE_URL . 'user/formulir.php?step=1';
$next_action_label = 'Mulai Isi Formulir';

if ($pendaftaran) {
    $is_data_pribadi_complete = !empty($pendaftaran['nama_calon']) && !empty($pendaftaran['nik']) && !empty($pendaftaran['nisn']) && !empty($pendaftaran['asal_sekolah']);
    $is_data_orang_tua_complete = !empty($pendaftaran['orang_tua_id']);
    $is_dokumen_complete = !empty($pendaftaran['dokumen_id']) && !empty($pendaftaran['foto']) && !empty($pendaftaran['ijazah_sd']) && !empty($pendaftaran['akta_kelahiran']) && !empty($pendaftaran['kartu_keluarga']);

    $completed_steps = ($is_data_pribadi_complete ? 1 : 0) + ($is_data_orang_tua_complete ? 1 : 0) + ($is_dokumen_complete ? 1 : 0);
    $progress = (int) round(($completed_steps / 3) * 100);
    $is_locked = $pendaftaran['status'] !== 'menunggu';

    if (!$is_data_pribadi_complete) {
        $next_action_url = BASE_URL . 'user/formulir.php?step=1';
        $next_action_label = 'Lengkapi Data Pribadi';
    } elseif (!$is_data_orang_tua_complete) {
        $next_action_url = BASE_URL . 'user/formulir.php?step=2';
        $next_action_label = 'Lengkapi Data Orang Tua';
    } elseif (!$is_dokumen_complete) {
        $next_action_url = BASE_URL . 'user/formulir.php?step=3';
        $next_action_label = 'Upload Dokumen';
    } else {
        $next_action_url = BASE_URL . 'user/status.php';
        $next_action_label = 'Lihat Status Pendaftaran';
    }
}

require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="dashboard-wrapper user-dashboard-page">
    <div class="container">
        <?php echo get_flash(); ?>

        <div class="dashboard-hero mb-4">
            <div class="row align-items-center g-4">
                <div class="col-lg-8">
                    <span class="hero-kicker">Area Calon Peserta Didik</span>
                    <h2 class="mb-2">Dashboard Pendaftaran</h2>
                    <p class="mb-0">
                        Selamat datang, <strong><?php echo htmlspecialchars(current_user_name()); ?></strong>.
                        Pantau kelengkapan data, status verifikasi, dan bukti pendaftaran Anda di halaman ini.
                    </p>
                </div>
                <div class="col-lg-4 text-lg-end">
                    <a href="<?php echo htmlspecialchars($next_action_url); ?>" class="btn btn-light btn-lg dashboard-hero-btn">
                        <i class="bi bi-arrow-right-circle me-1"></i>
                        <?php echo htmlspecialchars($next_action_label); ?>
                    </a>
                </div>
            </div>
        </div>

        <?php if ($pendaftaran) : ?>
            <div class="alert <?php echo $is_locked ? 'alert-info' : 'alert-warning'; ?> border-0 shadow-sm mb-4">
                <div class="d-flex gap-3 align-items-start">
                    <div class="fs-4">
                        <i class="bi <?php echo $is_locked ? 'bi-lock-fill' : 'bi-pencil-square'; ?>"></i>
                    </div>
                    <div>
                        <strong><?php echo $is_locked ? 'Data pendaftaran sudah dikunci.' : 'Data masih dapat diperbaiki.'; ?></strong>
                        <div class="small mt-1">
                            <?php if ($is_locked) : ?>
                                Data sudah diverifikasi oleh admin sehingga formulir tidak dapat diubah lagi. Silakan lihat catatan admin pada halaman status.
                            <?php else : ?>
                                Data masih dapat diperbaiki selama belum diverifikasi admin. Pastikan semua tahapan sudah lengkap sebelum menunggu keputusan final.
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-lg-3 col-md-6">
                    <div class="stat-card modern-stat-card">
                        <div class="stat-icon"><i class="bi bi-card-checklist"></i></div>
                        <div class="stat-label">Nomor Pendaftaran</div>
                        <div class="fw-bold fs-5 text-primary-custom">
                            <?php echo htmlspecialchars($pendaftaran['no_pendaftaran']); ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="stat-card modern-stat-card">
                        <div class="stat-icon"><i class="bi bi-hourglass-split"></i></div>
                        <div class="stat-label">Status</div>
                        <div class="mt-2"><?php echo badge_status($pendaftaran['status']); ?></div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="stat-card modern-stat-card">
                        <div class="stat-icon"><i class="bi bi-calendar-check"></i></div>
                        <div class="stat-label">Tanggal Daftar</div>
                        <div class="fw-bold fs-5 text-primary-custom">
                            <?php echo format_tanggal($pendaftaran['tanggal_daftar']); ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="stat-card modern-stat-card">
                        <div class="stat-icon"><i class="bi bi-clipboard2-check"></i></div>
                        <div class="stat-label">Kelengkapan</div>
                        <div class="fw-bold fs-5 text-primary-custom"><?php echo $progress; ?>%</div>
                    </div>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-lg-8">
                    <div class="content-card h-100">
                        <div class="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-4">
                            <div>
                                <h4 class="mb-1"><i class="bi bi-graph-up-arrow me-2"></i>Progress Kelengkapan Formulir</h4>
                                <p class="text-muted mb-0">Lengkapi tiga tahapan utama agar admin dapat memverifikasi pendaftaran.</p>
                            </div>
                            <span class="progress-pill"><?php echo $completed_steps; ?>/3 tahap selesai</span>
                        </div>

                        <div class="progress completion-progress mb-4">
                            <div class="progress-bar" role="progressbar" style="width: <?php echo $progress; ?>%;" aria-valuenow="<?php echo $progress; ?>" aria-valuemin="0" aria-valuemax="100">
                                <?php echo $progress; ?>%
                            </div>
                        </div>

                        <div class="row g-3">
                            <div class="col-md-4">
                                <div class="completion-step <?php echo $is_data_pribadi_complete ? 'completed' : 'pending'; ?>">
                                    <div class="completion-icon">
                                        <i class="bi <?php echo $is_data_pribadi_complete ? 'bi-check-circle-fill' : 'bi-circle'; ?>"></i>
                                    </div>
                                    <h6>Data Pribadi</h6>
                                    <p>NIK, NISN, biodata, alamat, dan asal sekolah.</p>
                                    <a href="<?php echo BASE_URL; ?>user/formulir.php?step=1" class="stretched-link"></a>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="completion-step <?php echo $is_data_orang_tua_complete ? 'completed' : 'pending'; ?>">
                                    <div class="completion-icon">
                                        <i class="bi <?php echo $is_data_orang_tua_complete ? 'bi-check-circle-fill' : 'bi-circle'; ?>"></i>
                                    </div>
                                    <h6>Data Orang Tua</h6>
                                    <p>Nama ayah/ibu, pekerjaan, kontak, dan penghasilan.</p>
                                    <a href="<?php echo BASE_URL; ?>user/formulir.php?step=2" class="stretched-link"></a>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="completion-step <?php echo $is_dokumen_complete ? 'completed' : 'pending'; ?>">
                                    <div class="completion-icon">
                                        <i class="bi <?php echo $is_dokumen_complete ? 'bi-check-circle-fill' : 'bi-circle'; ?>"></i>
                                    </div>
                                    <h6>Upload Dokumen</h6>
                                    <p>Pas foto, ijazah/STTB, akta kelahiran, dan KK.</p>
                                    <a href="<?php echo BASE_URL; ?>user/formulir.php?step=3" class="stretched-link"></a>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex flex-wrap gap-2 mt-4">
                            <a href="<?php echo htmlspecialchars($next_action_url); ?>" class="btn btn-primary-custom">
                                <i class="bi bi-pencil-square me-1"></i>
                                <?php echo htmlspecialchars($next_action_label); ?>
                            </a>
                            <a href="<?php echo BASE_URL; ?>user/status.php" class="btn btn-outline-primary-custom">
                                <i class="bi bi-search me-1"></i>
                                Lihat Status
                            </a>
                            <?php if ($is_dokumen_complete) : ?>
                                <a href="<?php echo BASE_URL; ?>user/cetak_bukti.php" target="_blank" class="btn btn-success btn-soft-success">
                                    <i class="bi bi-printer-fill me-1"></i>
                                    Cetak Bukti
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <div class="content-card h-100">
                        <h5 class="mb-3"><i class="bi bi-person-vcard me-2"></i>Ringkasan Pendaftaran</h5>
                        <div class="profile-summary-list">
                            <div>
                                <span>Nama Calon</span>
                                <strong><?php echo !empty($pendaftaran['nama_calon']) ? htmlspecialchars($pendaftaran['nama_calon']) : '-'; ?></strong>
                            </div>
                            <div>
                                <span>NISN</span>
                                <strong><?php echo !empty($pendaftaran['nisn']) ? htmlspecialchars($pendaftaran['nisn']) : '-'; ?></strong>
                            </div>
                            <div>
                                <span>Asal Sekolah</span>
                                <strong><?php echo !empty($pendaftaran['asal_sekolah']) ? htmlspecialchars($pendaftaran['asal_sekolah']) : '-'; ?></strong>
                            </div>
                            <div>
                                <span>Catatan Admin</span>
                                <strong><?php echo !empty($pendaftaran['catatan_admin']) ? nl2br(htmlspecialchars($pendaftaran['catatan_admin'])) : '-'; ?></strong>
                            </div>
                        </div>

                        <hr>

                        <h6 class="fw-bold text-primary-custom mb-3">Panduan Singkat</h6>
                        <ul class="timeline-mini mb-0">
                            <li class="done">Registrasi akun berhasil</li>
                            <li class="<?php echo $is_data_pribadi_complete ? 'done' : 'todo'; ?>">Lengkapi data pribadi</li>
                            <li class="<?php echo $is_data_orang_tua_complete ? 'done' : 'todo'; ?>">Lengkapi data orang tua</li>
                            <li class="<?php echo $is_dokumen_complete ? 'done' : 'todo'; ?>">Upload dokumen persyaratan</li>
                            <li class="<?php echo $pendaftaran['status'] !== 'menunggu' ? 'done' : 'todo'; ?>">Menunggu verifikasi admin</li>
                        </ul>
                    </div>
                </div>
            </div>

        <?php else : ?>
            <div class="content-card">
                <div class="empty-state empty-state-modern">
                    <div class="empty-illustration">
                        <i class="bi bi-file-earmark-text"></i>
                    </div>
                    <h5 class="mt-3">Anda Belum Mengisi Formulir Pendaftaran</h5>
                    <p>
                        Silakan mulai pengisian formulir untuk mendapatkan nomor pendaftaran PPDB.
                        Setelah itu Anda dapat mengunggah dokumen dan memantau status verifikasi.
                    </p>
                    <a href="<?php echo BASE_URL; ?>user/formulir.php?step=1" class="btn btn-primary-custom btn-lg">
                        <i class="bi bi-pencil-square me-1"></i>
                        Mulai Isi Formulir
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
