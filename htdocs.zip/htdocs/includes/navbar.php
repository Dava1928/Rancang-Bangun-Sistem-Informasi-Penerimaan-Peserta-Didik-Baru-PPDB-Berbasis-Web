<?php
// =========================================================
// File: includes/navbar.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Navbar utama berdasarkan role pengguna
// =========================================================

require_once __DIR__ . '/../config/session.php';

$current_page = basename($_SERVER['PHP_SELF']);
$current_folder = basename(dirname($_SERVER['PHP_SELF']));

function nav_active($page_name, $folder_name = '')
{
    global $current_page, $current_folder;
    if (!empty($folder_name)) {
        return ($current_page === $page_name && $current_folder === $folder_name) ? 'active' : '';
    }
    return ($current_page === $page_name) ? 'active' : '';
}
?>

<nav class="navbar navbar-expand-lg navbar-custom sticky-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center" href="<?php echo BASE_URL; ?>index.php">
            <span class="brand-icon me-2"><i class="bi bi-mortarboard-fill"></i></span>
            <span><span class="brand-title">MTS SA BINARAHMAH</span><small class="brand-subtitle d-none d-sm-block">PPDB Online</small></span>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbar" aria-controls="mainNavbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <?php if (!is_logged_in()) : ?>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('index.php'); ?>" href="<?php echo BASE_URL; ?>index.php">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('profil.php'); ?>" href="<?php echo BASE_URL; ?>profil.php">Profil</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('panduan.php'); ?>" href="<?php echo BASE_URL; ?>panduan.php">Panduan</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('pengumuman.php'); ?>" href="<?php echo BASE_URL; ?>pengumuman.php">Pengumuman</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('kontak.php'); ?>" href="<?php echo BASE_URL; ?>kontak.php">Kontak</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('login.php'); ?>" href="<?php echo BASE_URL; ?>login.php">Login</a></li>
                    <li class="nav-item"><a class="btn btn-light nav-cta ms-lg-2 mt-2 mt-lg-0" href="<?php echo BASE_URL; ?>register.php"><i class="bi bi-person-plus me-1"></i> Daftar</a></li>
                <?php elseif (is_user()) : ?>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('dashboard.php', 'user'); ?>" href="<?php echo BASE_URL; ?>user/dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('formulir.php', 'user'); ?>" href="<?php echo BASE_URL; ?>user/formulir.php">Formulir</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('status.php', 'user'); ?>" href="<?php echo BASE_URL; ?>user/status.php">Status</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('pengumuman.php'); ?>" href="<?php echo BASE_URL; ?>pengumuman.php">Pengumuman</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-person-circle me-1"></i><?php echo htmlspecialchars(current_user_name()); ?></a>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0" aria-labelledby="userDropdown">
                            <li><span class="dropdown-item-text small text-muted"><?php echo htmlspecialchars(current_user_email()); ?></span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>panduan.php"><i class="bi bi-journal-check me-2"></i>Panduan</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>user/cetak_bukti.php" target="_blank"><i class="bi bi-printer me-2"></i>Cetak Bukti</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>kontak.php"><i class="bi bi-headset me-2"></i>Bantuan</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="<?php echo BASE_URL; ?>logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                <?php elseif (is_admin()) : ?>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('dashboard.php', 'admin'); ?>" href="<?php echo BASE_URL; ?>admin/dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('pendaftar.php', 'admin'); ?>" href="<?php echo BASE_URL; ?>admin/pendaftar.php">Data Pendaftar</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo nav_active('pengumuman.php'); ?>" href="<?php echo BASE_URL; ?>pengumuman.php">Pengumuman</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-person-gear me-1"></i><?php echo htmlspecialchars(current_user_name()); ?></a>
                        <ul class="dropdown-menu dropdown-menu-end shadow-sm border-0" aria-labelledby="adminDropdown">
                            <li><span class="dropdown-item-text small text-muted">Administrator PPDB</span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>admin/export_excel.php"><i class="bi bi-file-earmark-excel me-2"></i>Export Excel</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>admin/ubah_password.php"><i class="bi bi-key me-2"></i>Ubah Password</a></li>
                            <li><a class="dropdown-item" href="<?php echo BASE_URL; ?>index.php"><i class="bi bi-globe2 me-2"></i>Lihat Website</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-danger" href="<?php echo BASE_URL; ?>logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
