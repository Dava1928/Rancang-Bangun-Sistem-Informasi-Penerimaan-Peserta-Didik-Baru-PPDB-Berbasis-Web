<?php
// =========================================================
// File: includes/header.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Header utama halaman
// =========================================================

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';

if (!isset($page_title) || empty($page_title)) {
    $page_title = 'PPDB Online MTS SA BINARAHMAH';
}

$current_page = basename($_SERVER['PHP_SELF']);
$current_folder = basename(dirname($_SERVER['PHP_SELF']));
$body_class = 'ppdb-page';

if ($current_folder === 'admin') {
    $body_class .= ' ppdb-admin-page';
} elseif ($current_folder === 'user') {
    $body_class .= ' ppdb-user-page';
} else {
    $body_class .= ' ppdb-public-page';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <meta name="description" content="Sistem Informasi PPDB Online MTS SA BINARAHMAH untuk pendaftaran peserta didik baru secara mudah, cepat, transparan, dan terstruktur.">
    <meta name="theme-color" content="#1a5276">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
</head>
<body class="<?php echo htmlspecialchars($body_class); ?>">
