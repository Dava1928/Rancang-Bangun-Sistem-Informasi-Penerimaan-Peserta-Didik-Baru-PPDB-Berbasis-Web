<?php
// =========================================================
// File: includes/admin_sidebar.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Sidebar khusus halaman admin
// =========================================================

require_once __DIR__ . '/../config/session.php';
$current_page = basename($_SERVER['PHP_SELF']);
$current_folder = basename(dirname($_SERVER['PHP_SELF']));
function admin_sidebar_active($page_name)
{
    global $current_page, $current_folder;
    return ($current_folder === 'admin' && $current_page === $page_name) ? 'active' : '';
}
?>
<aside class="admin-sidebar no-print">
    <div class="admin-sidebar-brand">
        <div class="brand-icon"><i class="bi bi-mortarboard-fill"></i></div>
        <div><strong>PPDB Admin</strong><span>MTS SA BINARAHMAH</span></div>
    </div>
    <div class="admin-menu">
        <a href="<?php echo BASE_URL; ?>admin/dashboard.php" class="<?php echo admin_sidebar_active('dashboard.php'); ?>"><i class="bi bi-speedometer2"></i><span>Dashboard</span></a>
        <a href="<?php echo BASE_URL; ?>admin/pendaftar.php" class="<?php echo admin_sidebar_active('pendaftar.php'); ?>"><i class="bi bi-people-fill"></i><span>Data Pendaftar</span></a>
        <a href="<?php echo BASE_URL; ?>pengumuman.php"><i class="bi bi-megaphone-fill"></i><span>Pengumuman</span></a>
        <a href="<?php echo BASE_URL; ?>admin/export_excel.php"><i class="bi bi-file-earmark-excel-fill"></i><span>Export Excel</span></a>
        <a href="<?php echo BASE_URL; ?>admin/ubah_password.php" class="<?php echo admin_sidebar_active('ubah_password.php'); ?>"><i class="bi bi-key-fill"></i><span>Ubah Password</span></a>
        <a href="<?php echo BASE_URL; ?>index.php"><i class="bi bi-globe2"></i><span>Lihat Website</span></a>
        <a href="<?php echo BASE_URL; ?>logout.php" class="text-warning"><i class="bi bi-box-arrow-right"></i><span>Logout</span></a>
    </div>
</aside>
