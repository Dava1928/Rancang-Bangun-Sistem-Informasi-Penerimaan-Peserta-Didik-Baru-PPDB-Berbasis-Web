<?php
// =========================================================
// File: includes/footer.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Footer utama halaman
// =========================================================
?>
<footer class="footer no-print">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6">
                <h5 class="mb-3"><i class="bi bi-mortarboard-fill me-2"></i>MTS SA BINARAHMAH</h5>
                <p class="mb-3">Sistem Informasi PPDB Online untuk membantu proses penerimaan peserta didik baru secara mudah, cepat, transparan, dan terstruktur.</p>
                <span class="badge bg-light text-primary-custom"><i class="bi bi-shield-check me-1"></i>PPDB Online</span>
            </div>
            <div class="col-lg-2 col-md-6">
                <h6 class="mb-3">Link Cepat</h6>
                <ul class="footer-link-list">
                    <li><a href="<?php echo BASE_URL; ?>index.php">Beranda</a></li>
                    <li><a href="<?php echo BASE_URL; ?>profil.php">Profil</a></li>
                    <li><a href="<?php echo BASE_URL; ?>panduan.php">Panduan</a></li>
                    <li><a href="<?php echo BASE_URL; ?>pengumuman.php">Pengumuman</a></li>
                    <li><a href="<?php echo BASE_URL; ?>kontak.php">Kontak</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-6">
                <h6 class="mb-3">Layanan</h6>
                <ul class="footer-link-list">
                    <?php if (!is_logged_in()) : ?>
                        <li><a href="<?php echo BASE_URL; ?>register.php">Registrasi</a></li>
                        <li><a href="<?php echo BASE_URL; ?>login.php">Login</a></li>
                    <?php elseif (is_admin()) : ?>
                        <li><a href="<?php echo BASE_URL; ?>admin/dashboard.php">Dashboard Admin</a></li>
                        <li><a href="<?php echo BASE_URL; ?>admin/pendaftar.php">Data Pendaftar</a></li>
                    <?php else : ?>
                        <li><a href="<?php echo BASE_URL; ?>user/dashboard.php">Dashboard User</a></li>
                        <li><a href="<?php echo BASE_URL; ?>user/formulir.php">Formulir Pendaftaran</a></li>
                        <li><a href="<?php echo BASE_URL; ?>user/status.php">Status Pendaftaran</a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="col-lg-3 col-md-6">
                <h6 class="mb-3">Kontak Panitia</h6>
                <ul class="footer-link-list">
                    <li><i class="bi bi-geo-alt me-2"></i>Bogor, Jawa Barat</li>
                    <li><i class="bi bi-envelope me-2"></i>ppdb@binarahmah.sch.id</li>
                    <li><i class="bi bi-whatsapp me-2"></i>08xx-xxxx-xxxx</li>
                    <li><i class="bi bi-clock me-2"></i>Senin - Sabtu, 08.00 - 14.00</li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom"><div class="row align-items-center gy-2"><div class="col-md-6 text-center text-md-start"><small>&copy; <?php echo date('Y'); ?> MTS SA BINARAHMAH.</small></div><div class="col-md-6 text-center text-md-end"><small>PHP Native, MySQL, Bootstrap 5.</small></div></div></div>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('form').forEach(function (form) {
        form.addEventListener('submit', function () {
            const btn = form.querySelector('button[type="submit"]');
            if (btn && !btn.classList.contains('no-loading')) {
                btn.classList.add('btn-loading');
                btn.setAttribute('aria-disabled', 'true');
                btn.style.pointerEvents = 'none';
                btn.innerText = btn.getAttribute('data-loading-text') || 'Memproses';
            }
        });
    });
    document.querySelectorAll('input[type="file"]').forEach(function (input) {
        input.addEventListener('change', function () {
            const fileName = this.files && this.files.length > 0 ? this.files[0].name : '';
            const wrapper = this.closest('.upload-card') || this.parentElement;
            if (!wrapper || !fileName) return;
            let preview = wrapper.querySelector('.selected-file-preview');
            if (!preview) { preview = document.createElement('div'); preview.className = 'selected-file-preview mt-2 small fw-semibold text-primary-custom'; wrapper.appendChild(preview); }
            preview.innerHTML = '<i class="bi bi-paperclip me-1"></i>' + fileName;
        });
    });
});
</script>
</body>
</html>
