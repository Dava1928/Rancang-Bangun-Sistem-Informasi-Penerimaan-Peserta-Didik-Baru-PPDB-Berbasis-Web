<?php
// =========================================================
// File: login.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Halaman login user dan admin
// =========================================================

$page_title = 'Login - PPDB Online MTS SA BINARAHMAH';
require_once __DIR__ . '/includes/header.php';

redirect_if_logged_in();

$email = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $rate_key = 'login_' . hash('sha256', client_ip() . '|' . $email);

    if (rate_limit_exceeded($rate_key, 5, 900)) {
        $error = 'Terlalu banyak percobaan login. Silakan coba lagi sekitar 15 menit kemudian.';
    } elseif (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        rate_limit_hit($rate_key);
        $error = 'Sesi formulir tidak valid. Silakan muat ulang halaman dan coba lagi.';
    } elseif (empty($email) || empty($password)) {
        rate_limit_hit($rate_key);
        $error = 'Email dan password wajib diisi.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        rate_limit_hit($rate_key);
        $error = 'Format email tidak valid.';
    } else {
        $user = db_fetch_one(
            'SELECT id, nama_lengkap, email, password, role FROM users WHERE email = ? LIMIT 1',
            's',
            [$email]
        );

        if ($user && password_verify($password, $user['password'])) {
            rate_limit_clear($rate_key);
            rotate_csrf_token();
            login_user($user);
            set_flash('success', 'Login berhasil. Selamat datang, ' . $user['nama_lengkap'] . '.');

            if ($user['role'] === 'admin') {
                header('Location: ' . BASE_URL . 'admin/dashboard.php');
                exit;
            }

            header('Location: ' . BASE_URL . 'user/dashboard.php');
            exit;
        }

        rate_limit_hit($rate_key);
        $error = 'Email atau password salah.';
    }
}

require_once __DIR__ . '/includes/navbar.php';
?>

<section class="auth-wrapper">
    <div class="container">
        <div class="row justify-content-center align-items-center g-4">
            <div class="col-lg-6 order-2 order-lg-1">
                <div class="auth-side-card">
                    <div class="position-relative z-2">
                        <span class="badge bg-light text-primary-custom mb-3">
                            <i class="bi bi-shield-check me-1"></i>
                            Portal PPDB Online
                        </span>

                        <h2 class="fw-850 mb-3">Masuk ke Sistem PPDB MTS SA BINARAHMAH</h2>
                        <p class="mb-4">
                            Kelola pendaftaran, upload dokumen, cetak bukti, dan pantau status verifikasi
                            dalam satu portal yang rapi dan mudah digunakan.
                        </p>

                        <div class="row g-3">
                            <div class="col-sm-6">
                                <div class="p-3 rounded-custom" style="background-color: rgba(255,255,255,0.14);">
                                    <i class="bi bi-pencil-square fs-3 mb-2 d-block"></i>
                                    <strong class="d-block">Formulir Online</strong>
                                    <span class="small text-white-50">Isi data pendaftaran bertahap.</span>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="p-3 rounded-custom" style="background-color: rgba(255,255,255,0.14);">
                                    <i class="bi bi-clipboard-check fs-3 mb-2 d-block"></i>
                                    <strong class="d-block">Status Real-time</strong>
                                    <span class="small text-white-50">Pantau hasil verifikasi admin.</span>
                                </div>
                            </div>
                        </div>

                        <ul class="list-unstyled mt-4 mb-0">
                            <li class="mb-2"><i class="bi bi-check-circle-fill me-2"></i>Akses calon peserta didik dan admin.</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill me-2"></i>Data pendaftaran tersimpan lebih rapi.</li>
                            <li><i class="bi bi-check-circle-fill me-2"></i>Dokumen dapat diperiksa secara online.</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-5 order-1 order-lg-2">
                <div class="auth-card">
                    <div class="text-center mb-4">
                        <div class="auth-icon"><i class="bi bi-box-arrow-in-right"></i></div>
                        <h3>Login Akun</h3>
                        <p class="text-muted mb-0">Masukkan email dan password untuk mengakses sistem.</p>
                    </div>

                    <?php echo get_flash(); ?>

                    <?php if (!empty($error)) : ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i>
                            <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="" method="POST" autocomplete="off">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="email" class="form-label required">Email</label>
                            <div class="input-icon-group">
                                <i class="bi bi-envelope input-icon"></i>
                                <input type="email" name="email" id="email" class="form-control" placeholder="Masukkan email aktif" value="<?php echo htmlspecialchars($email); ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label required">Password</label>
                            <div class="input-icon-group">
                                <i class="bi bi-lock input-icon"></i>
                                <input type="password" name="password" id="password" class="form-control" placeholder="Masukkan password" required>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="showPassword">
                                <label class="form-check-label small text-muted" for="showPassword">Tampilkan password</label>
                            </div>
                            <a href="<?php echo BASE_URL; ?>kontak.php" class="small text-primary-custom fw-semibold">Butuh bantuan?</a>
                        </div>

                        <div class="d-grid mb-3">
                            <button type="submit" class="btn btn-primary-custom" data-loading-text="Memproses">
                                <i class="bi bi-box-arrow-in-right me-1"></i>Login
                            </button>
                        </div>

                        <div class="text-center">
                            <p class="mb-0">Belum punya akun? <a href="<?php echo BASE_URL; ?>register.php" class="text-primary-custom fw-semibold">Daftar sekarang</a></p>
                        </div>
                    </form>
                </div>

                <div class="text-center mt-3">
                    <a href="<?php echo BASE_URL; ?>index.php" class="text-muted"><i class="bi bi-arrow-left me-1"></i>Kembali ke Beranda</a>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const showPassword = document.getElementById('showPassword');
    const passwordInput = document.getElementById('password');

    if (showPassword && passwordInput) {
        showPassword.addEventListener('change', function () {
            passwordInput.type = this.checked ? 'text' : 'password';
        });
    }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
