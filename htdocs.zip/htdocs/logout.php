<?php
require_once __DIR__ . '/config/session.php';
logout_user();
session_start();
set_flash('success', 'Anda berhasil logout.');
header('Location: ' . BASE_URL . 'login.php');
exit;
?>
