<?php
// =========================================================
// File: pengumuman.php (root folder)
// Sistem PPDB Online MTS SA BINARAHMAH
// Halaman pengumuman peserta yang diterima (publik)
// =========================================================

$page_title = 'Pengumuman PPDB - MTS SA BINARAHMAH';
require_once __DIR__ . '/includes/header.php';

$peserta_diterima = query_all(
    "SELECT p.no_pendaftaran, p.tanggal_daftar, dp.nama_lengkap, dp.nisn, dp.asal_sekolah
     FROM pendaftaran p
     INNER JOIN data_pribadi dp ON p.id = dp.pendaftaran_id
     WHERE p.status = 'diterima'
     ORDER BY dp.nama_lengkap ASC"
);

$total_diterima = count($peserta_diterima);
require_once __DIR__ . '/includes/navbar.php';
?>

<!-- Hero kecil -->
<div style="background: linear-gradient(135deg, #1a5276 0%, #1f618d 60%, #2980b9 100%); padding: 50px 0 40px;">
    <div class="container text-center text-white">
        <div style="font-size: 3rem; margin-bottom: 10px;">📢</div>
        <h2 class="fw-bold mb-2">Pengumuman PPDB</h2>
        <p style="opacity:0.85; font-size:1rem; margin-bottom:0;">
            Daftar Calon Peserta Didik Baru yang Dinyatakan <strong>DITERIMA</strong><br>
            MTS SA BINARAHMAH Tahun Ajaran <?= date('Y') ?>/<?= date('Y') + 1 ?>
        </p>
    </div>
</div>

<div class="container py-5">

    <!-- Info box -->
    <div class="alert border-0 mb-4" style="background: #eaf4fb; border-left: 5px solid #1a5276 !important; border-radius: 10px;">
        <div class="d-flex align-items-start gap-3">
            <div style="font-size:1.6rem;">ℹ️</div>
            <div>
                <strong style="color:#1a5276;">Perhatian</strong><br>
                <span style="font-size:0.9rem; color:#555;">
                    Halaman ini menampilkan daftar calon peserta didik yang telah dinyatakan
                    <strong>diterima</strong> melalui proses verifikasi oleh panitia PPDB MTS SA BINARAHMAH.
                    Peserta yang namanya tercantum di bawah ini wajib melakukan
                    <strong>daftar ulang</strong> sesuai jadwal yang telah ditetapkan.
                    Data sensitif seperti NIK, alamat, dan nomor telepon tidak ditampilkan demi privasi.
                </span>
            </div>
        </div>
    </div>

    <!-- Statistik -->
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card border-0 text-center p-4" style="background: linear-gradient(135deg,#1e8449,#27ae60); border-radius:14px; color:white; box-shadow:0 4px 15px rgba(39,174,96,0.3);">
                <div style="font-size:2.5rem; font-weight:800;"><?= $total_diterima ?></div>
                <div style="font-size:0.9rem; opacity:0.9;">Peserta Diterima</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 text-center p-4" style="background: linear-gradient(135deg,#1a5276,#2980b9); border-radius:14px; color:white; box-shadow:0 4px 15px rgba(26,82,118,0.3);">
                <div style="font-size:2.5rem; font-weight:800;"><?= date('Y') ?>/<?= date('Y') + 1 ?></div>
                <div style="font-size:0.9rem; opacity:0.9;">Tahun Ajaran</div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-0 text-center p-4" style="background: linear-gradient(135deg,#7d6608,#d4ac0d); border-radius:14px; color:white; box-shadow:0 4px 15px rgba(212,172,13,0.3);">
                <div style="font-size:1.6rem; font-weight:800;">MTS SA</div>
                <div style="font-size:0.9rem; opacity:0.9;">BINARAHMAH</div>
            </div>
        </div>
    </div>

    <!-- Tabel peserta diterima -->
    <div class="card border-0" style="border-radius:14px; box-shadow:0 4px 20px rgba(0,0,0,0.08);">
        <div class="card-header border-0 d-flex justify-content-between align-items-center"
             style="background: linear-gradient(135deg,#1a5276,#2980b9); border-radius:14px 14px 0 0; padding:18px 24px;">
            <div>
                <h5 class="mb-0 text-white fw-bold">
                    <i class="bi bi-award-fill me-2"></i>Daftar Peserta Diterima
                </h5>
                <small style="color:rgba(255,255,255,0.75);">
                    Diperbarui: <?= date('d F Y, H:i') ?> WIB
                </small>
            </div>
            <span class="badge" style="background:rgba(255,255,255,0.2); font-size:0.85rem; padding:8px 14px;">
                <?= $total_diterima ?> Peserta
            </span>
        </div>
        <div class="card-body p-0">

            <?php if ($total_diterima > 0) : ?>

                <!-- Search client-side -->
                <div class="p-4 pb-0">
                    <div class="input-group" style="max-width:400px;">
                        <span class="input-group-text border-end-0" style="background:#f8f9fa; border-color:#dee2e6;">
                            <i class="bi bi-search" style="color:#1a5276;"></i>
                        </span>
                        <input type="text" id="searchInput" class="form-control border-start-0"
                               placeholder="Cari nama atau asal sekolah..."
                               style="background:#f8f9fa;" onkeyup="filterTable()">
                    </div>
                    <p class="text-muted mt-2 mb-0" style="font-size:0.8rem;">
                        Menampilkan <span id="countVisible"><?= $total_diterima ?></span> dari <?= $total_diterima ?> peserta diterima
                    </p>
                </div>

                <div class="table-responsive p-4 pt-3">
                    <table class="table table-bordered table-hover mb-0" id="tabelPengumuman">
                        <thead style="background:#1a5276; color:white;">
                            <tr>
                                <th style="width:50px; text-align:center;">No</th>
                                <th>Nomor Pendaftaran</th>
                                <th>Nama Calon Peserta Didik</th>
                                <th>NISN</th>
                                <th>Asal Sekolah</th>
                                <th style="text-align:center;">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1;
                            foreach ($peserta_diterima as $row) : ?>
                                <tr>
                                    <td class="text-center fw-bold"><?= $no++ ?></td>
                                    <td>
                                        <span class="badge"
                                            style="background:#1a5276; font-size:0.82rem; padding:6px 10px; font-weight:600; letter-spacing:0.5px;">
                                            <?= htmlspecialchars($row['no_pendaftaran']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <strong style="color:#1a5276;">
                                            <?= htmlspecialchars($row['nama_lengkap']) ?>
                                        </strong>
                                    </td>
                                    <td class="text-muted"><?= htmlspecialchars($row['nisn'] ?? '-') ?></td>
                                    <td><?= htmlspecialchars($row['asal_sekolah'] ?? '-') ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-success" style="font-size:0.8rem; padding:6px 12px;">
                                            <i class="bi bi-check-circle-fill me-1"></i>DITERIMA
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Keterangan daftar ulang -->
                <div class="p-4 pt-0">
                    <div class="alert border-0 mb-0"
                         style="background:#eafaf1; border-left:5px solid #27ae60 !important; border-radius:10px;">
                        <strong style="color:#1e8449;">📌 Informasi Daftar Ulang</strong><br>
                        <span style="font-size:0.88rem; color:#555;">
                            Peserta yang dinyatakan diterima wajib melakukan daftar ulang pada
                            <strong>11–15 Juli <?= date('Y') ?></strong> dengan membawa dokumen persyaratan asli.
                            Informasi lebih lanjut dapat menghubungi kantor madrasah.
                        </span>
                    </div>
                </div>

            <?php else : ?>

                <!-- Empty State -->
                <div class="text-center py-5 px-4">
                    <div style="font-size:5rem; margin-bottom:15px;">📋</div>
                    <h5 style="color:#1a5276; font-weight:700;">Pengumuman Belum Tersedia</h5>
                    <p class="text-muted mb-4" style="max-width:400px; margin:0 auto;">
                        Daftar peserta yang diterima akan ditampilkan di sini setelah proses
                        seleksi dan verifikasi oleh panitia PPDB selesai dilakukan.
                    </p>
                    <a href="<?= BASE_URL ?>index.php" class="btn"
                       style="background:linear-gradient(135deg,#1a5276,#2980b9); color:white; border:none; border-radius:8px; padding:10px 24px; font-weight:600;">
                        <i class="bi bi-house-fill me-2"></i>Kembali ke Beranda
                    </a>
                </div>

            <?php endif; ?>

        </div>
    </div>

    <!-- Tombol navigasi -->
    <div class="d-flex flex-wrap justify-content-between align-items-center mt-4 gap-2">
        <a href="<?= BASE_URL ?>index.php"
           class="btn btn-outline-secondary" style="border-radius:8px;">
            <i class="bi bi-arrow-left me-1"></i>Kembali ke Beranda
        </a>
        <?php if (!is_logged_in()) : ?>
            <div class="d-flex gap-2">
                <a href="<?= BASE_URL ?>login.php" class="btn btn-outline-primary"
                   style="border-color:#1a5276; color:#1a5276; border-radius:8px;">
                    <i class="bi bi-box-arrow-in-right me-1"></i>Login
                </a>
                <a href="<?= BASE_URL ?>register.php" class="btn"
                   style="background:linear-gradient(135deg,#1a5276,#2980b9); color:white; border:none; border-radius:8px; font-weight:600;">
                    <i class="bi bi-person-plus me-1"></i>Daftar Sekarang
                </a>
            </div>
        <?php elseif (is_user()) : ?>
            <a href="<?= BASE_URL ?>user/status.php" class="btn"
               style="background:linear-gradient(135deg,#1a5276,#2980b9); color:white; border:none; border-radius:8px; font-weight:600;">
                <i class="bi bi-search me-1"></i>Cek Status Saya
            </a>
        <?php endif; ?>
    </div>

</div>

<script>
function filterTable() {
    const input = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('#tabelPengumuman tbody tr');
    let visible = 0;
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        const show = text.includes(input);
        row.style.display = show ? '' : 'none';
        if (show) visible++;
    });
    document.getElementById('countVisible').textContent = visible;
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
