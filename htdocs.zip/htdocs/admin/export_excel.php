<?php
// =========================================================
// File: admin/export_excel.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Export laporan data pendaftar ke format Excel (.xls)
// =========================================================

require_once __DIR__ . '/../config/session.php';
require_once __DIR__ . '/../config/database.php';
require_admin();

// Ambil semua data pendaftar lengkap
$pendaftar = query_all(
    "SELECT p.no_pendaftaran, p.status, p.tanggal_daftar,
            u.nama_lengkap AS nama_akun, u.email,
            dp.nama_lengkap AS nama_calon, dp.nisn, dp.nik,
            dp.tempat_lahir, dp.tanggal_lahir, dp.jenis_kelamin,
            dp.agama, dp.asal_sekolah, dp.no_telepon, dp.alamat,
            dot.nama_ayah, dot.nama_ibu, dot.no_telepon_ortu,
            CASE
                WHEN dp.pendaftaran_id IS NOT NULL AND dot.pendaftaran_id IS NOT NULL AND d.pendaftaran_id IS NOT NULL
                THEN 'Lengkap'
                ELSE 'Belum Lengkap'
            END AS kelengkapan
     FROM pendaftaran p
     INNER JOIN users u ON p.user_id = u.id
     LEFT JOIN data_pribadi dp ON p.id = dp.pendaftaran_id
     LEFT JOIN data_orang_tua dot ON p.id = dot.pendaftaran_id
     LEFT JOIN dokumen d ON p.id = d.pendaftaran_id
     ORDER BY p.tanggal_daftar DESC"
);

$nama_file = 'Laporan_PPDB_MTS_Binarahmah_' . date('Ymd_His') . '.xls';

// Header HTTP untuk download Excel
header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . $nama_file . '"');
header('Cache-Control: max-age=0');
header('Pragma: public');

// Label status
function label_status($status) {
    $map = ['menunggu' => 'Menunggu Verifikasi', 'diterima' => 'Diterima', 'ditolak' => 'Ditolak'];
    return $map[$status] ?? ucfirst($status);
}

// Label jenis kelamin
function label_jk($jk) {
    if ($jk === 'L') return 'Laki-laki';
    if ($jk === 'P') return 'Perempuan';
    return '-';
}
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:x="urn:schemas-microsoft-com:office:excel"
      xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <meta charset="UTF-8">
    <!--[if gte mso 9]>
    <xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>
        <x:Name>Laporan PPDB</x:Name>
        <x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions>
    </x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml>
    <![endif]-->
    <style>
        body { font-family: Calibri, Arial, sans-serif; font-size: 11pt; }
        .judul { font-size: 14pt; font-weight: bold; text-align: center; }
        .subjudul { font-size: 11pt; text-align: center; color: #444; }
        .tanggal-cetak { font-size: 9pt; text-align: center; color: #666; }
        th {
            background-color: #1a5276;
            color: white;
            font-weight: bold;
            text-align: center;
            border: 1px solid #ccc;
            padding: 6px 10px;
            white-space: nowrap;
        }
        td {
            border: 1px solid #ccc;
            padding: 5px 10px;
            vertical-align: top;
            font-size: 10pt;
        }
        tr:nth-child(even) td { background-color: #eaf2fb; }
        .status-diterima { color: #1e8449; font-weight: bold; }
        .status-ditolak  { color: #c0392b; font-weight: bold; }
        .status-menunggu { color: #7d6608; font-weight: bold; }
        .center { text-align: center; }
        .footer-row td { background-color: #eaf2fb; font-style: italic; color: #555; font-size: 9pt; }
    </style>
</head>
<body>

<table>
    <!-- Baris Judul -->
    <tr>
        <td colspan="11" class="judul">LAPORAN DATA PENDAFTAR PPDB ONLINE</td>
    </tr>
    <tr>
        <td colspan="11" class="subjudul">MTS SA BINARAHMAH — Tahun Ajaran <?= date('Y') ?>/<?= date('Y') + 1 ?></td>
    </tr>
    <tr>
        <td colspan="11" class="tanggal-cetak">Dicetak pada: <?= date('d F Y, H:i:s') ?> WIB oleh Administrator</td>
    </tr>
    <tr><td colspan="11"></td></tr><!-- Baris kosong -->

    <!-- Header Tabel -->
    <tr>
        <th>No</th>
        <th>Nomor Pendaftaran</th>
        <th>Nama Calon Peserta Didik</th>
        <th>NISN</th>
        <th>Asal Sekolah (SD/MI)</th>
        <th>Jenis Kelamin</th>
        <th>Agama</th>
        <th>Email Akun</th>
        <th>Nomor Telepon</th>
        <th>Kelengkapan Data</th>
        <th>Status Pendaftaran</th>
        <th>Tanggal Daftar</th>
        <th>Nama Ayah</th>
        <th>Nama Ibu</th>
    </tr>

    <!-- Data -->
    <?php if (count($pendaftar) > 0) : ?>
        <?php $no = 1;
        foreach ($pendaftar as $row) :
            $st = $row['status'] ?? 'menunggu';
            $st_class = 'status-' . $st;
        ?>
        <tr>
            <td class="center"><?= $no++ ?></td>
            <td><b><?= htmlspecialchars($row['no_pendaftaran'] ?? '-') ?></b></td>
            <td><?= htmlspecialchars($row['nama_calon'] ?? $row['nama_akun'] ?? '-') ?></td>
            <td class="center"><?= htmlspecialchars($row['nisn'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['asal_sekolah'] ?? '-') ?></td>
            <td class="center"><?= label_jk($row['jenis_kelamin'] ?? '') ?></td>
            <td><?= htmlspecialchars($row['agama'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['email'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['no_telepon'] ?? '-') ?></td>
            <td class="center"><?= htmlspecialchars($row['kelengkapan'] ?? '-') ?></td>
            <td class="center <?= $st_class ?>"><?= label_status($st) ?></td>
            <td class="center"><?= format_tanggal($row['tanggal_daftar'] ?? '') ?></td>
            <td><?= htmlspecialchars($row['nama_ayah'] ?? '-') ?></td>
            <td><?= htmlspecialchars($row['nama_ibu'] ?? '-') ?></td>
        </tr>
        <?php endforeach; ?>
    <?php else : ?>
        <tr><td colspan="14" class="center" style="color:#888;font-style:italic;padding:20px;">Tidak ada data pendaftar.</td></tr>
    <?php endif; ?>

    <!-- Baris kosong dan ringkasan -->
    <tr><td colspan="14"></td></tr>
    <tr class="footer-row">
        <td colspan="14">
            Total Pendaftar: <?= count($pendaftar) ?> &nbsp;|&nbsp;
            Diterima: <?= count(array_filter($pendaftar, fn($r) => $r['status'] === 'diterima')) ?> &nbsp;|&nbsp;
            Ditolak: <?= count(array_filter($pendaftar, fn($r) => $r['status'] === 'ditolak')) ?> &nbsp;|&nbsp;
            Menunggu: <?= count(array_filter($pendaftar, fn($r) => $r['status'] === 'menunggu')) ?>
        </td>
    </tr>
    <tr class="footer-row">
        <td colspan="14">
            Dokumen ini digenerate secara otomatis oleh Sistem PPDB Online MTS SA BINARAHMAH.
            Hanya untuk keperluan internal administrasi.
        </td>
    </tr>

</table>
</body>
</html>
