<?php
// =========================================================
// File: admin/dashboard.php — UPDATED: Chart.js + tampilan modern
// =========================================================
$page_title = 'Dashboard Admin - PPDB Online MTS SA BINARAHMAH';
require_once __DIR__ . '/../includes/header.php';
require_admin();

$total_pendaftar    = (int)(query_single("SELECT COUNT(*) AS total FROM pendaftaran")['total'] ?? 0);
$total_menunggu     = (int)(query_single("SELECT COUNT(*) AS total FROM pendaftaran WHERE status='menunggu'")['total'] ?? 0);
$total_diterima     = (int)(query_single("SELECT COUNT(*) AS total FROM pendaftaran WHERE status='diterima'")['total'] ?? 0);
$total_ditolak      = (int)(query_single("SELECT COUNT(*) AS total FROM pendaftaran WHERE status='ditolak'")['total'] ?? 0);
$total_lengkap      = (int)(query_single("SELECT COUNT(*) AS total FROM pendaftaran p INNER JOIN data_pribadi dp ON p.id=dp.pendaftaran_id INNER JOIN data_orang_tua dot ON p.id=dot.pendaftaran_id INNER JOIN dokumen d ON p.id=d.pendaftaran_id")['total'] ?? 0);
$total_belum_lengkap = max(0, $total_pendaftar - $total_lengkap);
$persen_diterima    = $total_pendaftar > 0 ? round(($total_diterima / $total_pendaftar) * 100) : 0;

$pendaftar_terbaru = query_all("SELECT p.id, p.no_pendaftaran, p.status, p.tanggal_daftar, u.nama_lengkap AS nama_akun, u.email, dp.nama_lengkap AS nama_calon, dp.asal_sekolah FROM pendaftaran p INNER JOIN users u ON p.user_id=u.id LEFT JOIN data_pribadi dp ON p.id=dp.pendaftaran_id ORDER BY p.tanggal_daftar DESC LIMIT 5");

require_once __DIR__ . '/../includes/navbar.php';
?>
<div class="dashboard-wrapper"><div class="container"><?php echo get_flash(); ?>

<!-- Header -->
<div class="row align-items-center mb-4">
    <div class="col-md-7"><h2 class="page-title">Dashboard Administrator</h2><p class="page-subtitle mb-0">Kelola data pendaftaran PPDB Online MTS SA BINARAHMAH.</p></div>
    <div class="col-md-5 text-md-end d-flex flex-wrap gap-2 justify-content-md-end mt-2 mt-md-0">
        <a href="<?php echo BASE_URL; ?>admin/pendaftar.php" class="btn btn-primary-custom"><i class="bi bi-people-fill me-1"></i>Kelola Pendaftar</a>
        <a href="<?php echo BASE_URL; ?>admin/export_excel.php" class="btn btn-success" style="border-radius:8px;font-weight:600;"><i class="bi bi-file-earmark-excel-fill me-1"></i>Export Excel</a>
    </div>
</div>

<!-- Stat Cards -->
<div class="row g-3 mb-4">
    <?php foreach([
        ['linear-gradient(135deg,#1a5276,#2980b9)','bi-people-fill','Total Pendaftar',$total_pendaftar],
        ['linear-gradient(135deg,#7d6608,#d4ac0d)','bi-hourglass-split','Menunggu Verifikasi',$total_menunggu],
        ['linear-gradient(135deg,#1e8449,#27ae60)','bi-check-circle-fill','Diterima',$total_diterima],
        ['linear-gradient(135deg,#922b21,#e74c3c)','bi-x-circle-fill','Ditolak',$total_ditolak],
    ] as $s): ?>
    <div class="col-lg-3 col-md-6">
        <div class="stat-card" style="background:<?php echo $s[0]; ?>;">
            <div class="stat-icon"><i class="bi <?php echo $s[1]; ?>"></i></div>
            <div class="stat-number"><?php echo $s[3]; ?></div>
            <div class="stat-label"><?php echo $s[2]; ?></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Grafik Row -->
<div class="row g-4 mb-4">

    <!-- Donut: Status -->
    <div class="col-lg-5">
        <div class="content-card h-100">
            <h5 class="mb-1"><i class="bi bi-pie-chart-fill me-2" style="color:#1a5276;"></i>Statistik Status Pendaftar</h5>
            <p class="text-muted mb-3" style="font-size:0.85rem;">Distribusi status seluruh pendaftar PPDB.</p>
            <?php if($total_pendaftar>0): ?>
            <div style="position:relative;height:220px;display:flex;align-items:center;justify-content:center;">
                <canvas id="chartStatus"></canvas>
            </div>
            <div class="row text-center mt-3">
                <div class="col-4"><div class="fw-bold" style="color:#d4ac0d;font-size:1.3rem;"><?php echo $total_menunggu; ?></div><div style="font-size:0.75rem;color:#666;">Menunggu</div></div>
                <div class="col-4"><div class="fw-bold" style="color:#27ae60;font-size:1.3rem;"><?php echo $total_diterima; ?></div><div style="font-size:0.75rem;color:#666;">Diterima</div></div>
                <div class="col-4"><div class="fw-bold" style="color:#e74c3c;font-size:1.3rem;"><?php echo $total_ditolak; ?></div><div style="font-size:0.75rem;color:#666;">Ditolak</div></div>
            </div>
            <?php else: ?><div class="text-center py-4 text-muted"><i class="bi bi-bar-chart" style="font-size:3rem;opacity:0.3;"></i><p class="mt-2 small">Belum ada data pendaftar.</p></div><?php endif; ?>
        </div>
    </div>

    <!-- Bar: Kelengkapan -->
    <div class="col-lg-4">
        <div class="content-card h-100">
            <h5 class="mb-1"><i class="bi bi-bar-chart-fill me-2" style="color:#1a5276;"></i>Kelengkapan Data</h5>
            <p class="text-muted mb-3" style="font-size:0.85rem;">Data lengkap = data pribadi + orang tua + dokumen terisi.</p>
            <?php if($total_pendaftar>0): ?>
            <div style="position:relative;height:200px;"><canvas id="chartKelengkapan"></canvas></div>
            <div class="row text-center mt-3">
                <div class="col-6"><div class="fw-bold" style="color:#27ae60;font-size:1.3rem;"><?php echo $total_lengkap; ?></div><div style="font-size:0.75rem;color:#666;">Data Lengkap</div></div>
                <div class="col-6"><div class="fw-bold" style="color:#e67e22;font-size:1.3rem;"><?php echo $total_belum_lengkap; ?></div><div style="font-size:0.75rem;color:#666;">Belum Lengkap</div></div>
            </div>
            <?php else: ?><div class="text-center py-4 text-muted"><i class="bi bi-clipboard-x" style="font-size:3rem;opacity:0.3;"></i><p class="mt-2 small">Belum ada data.</p></div><?php endif; ?>
        </div>
    </div>

    <!-- Menu Cepat + progress -->
    <div class="col-lg-3">
        <div class="content-card h-100 d-flex flex-column">
            <h5 class="mb-3"><i class="bi bi-lightning-charge-fill me-2" style="color:#1a5276;"></i>Menu Cepat</h5>
            <div class="d-grid gap-2 flex-grow-1">
                <a href="<?php echo BASE_URL; ?>admin/pendaftar.php" class="btn btn-primary-custom"><i class="bi bi-people-fill me-1"></i>Data Pendaftar</a>
                <a href="<?php echo BASE_URL; ?>admin/pendaftar.php?status=menunggu" class="btn btn-outline-primary-custom">
                    <i class="bi bi-hourglass-split me-1"></i>Perlu Diverifikasi
                    <?php if($total_menunggu>0): ?><span class="badge bg-danger ms-1"><?php echo $total_menunggu; ?></span><?php endif; ?>
                </a>
                <a href="<?php echo BASE_URL; ?>admin/export_excel.php" class="btn btn-success" style="border-radius:8px;font-weight:600;"><i class="bi bi-file-earmark-excel-fill me-1"></i>Export Excel</a>
                <a href="<?php echo BASE_URL; ?>pengumuman.php" target="_blank" class="btn btn-outline-secondary" style="border-radius:8px;"><i class="bi bi-megaphone me-1"></i>Lihat Pengumuman</a>
                <a href="<?php echo BASE_URL; ?>admin/ubah_password.php" class="btn btn-outline-secondary" style="border-radius:8px;"><i class="bi bi-key me-1"></i>Ubah Password</a>
            </div>
            <?php if($total_pendaftar>0): ?>
            <div class="mt-4 pt-3 border-top">
                <div class="d-flex justify-content-between mb-1" style="font-size:0.82rem;">
                    <span class="text-muted">Tingkat Penerimaan</span>
                    <strong style="color:#27ae60;"><?php echo $persen_diterima; ?>%</strong>
                </div>
                <div class="progress" style="height:8px;border-radius:10px;">
                    <div class="progress-bar bg-success" style="width:<?php echo $persen_diterima; ?>%;border-radius:10px;"></div>
                </div>
                <div style="font-size:0.75rem;color:#888;margin-top:4px;"><?php echo $total_diterima; ?> dari <?php echo $total_pendaftar; ?> pendaftar diterima</div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Tabel Terbaru -->
<div class="content-card">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div><h4 class="mb-1"><i class="bi bi-clock-history me-2"></i>Pendaftar Terbaru</h4><p class="text-muted mb-0">Lima data pendaftaran terbaru.</p></div>
        <a href="<?php echo BASE_URL; ?>admin/pendaftar.php" class="btn btn-sm btn-outline-primary-custom">Lihat Semua <i class="bi bi-arrow-right ms-1"></i></a>
    </div>
    <?php if(count($pendaftar_terbaru)>0): ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover mb-0">
            <thead><tr><th>No</th><th>No. Pendaftaran</th><th>Nama Calon</th><th>Asal Sekolah</th><th>Status</th><th>Tanggal</th><th>Aksi</th></tr></thead>
            <tbody>
                <?php $no=1; foreach($pendaftar_terbaru as $row): ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><strong><?php echo htmlspecialchars($row['no_pendaftaran']); ?></strong></td>
                    <td><?php echo htmlspecialchars($row['nama_calon'] ?? $row['nama_akun']); ?><br><small class="text-muted"><?php echo htmlspecialchars($row['email']); ?></small></td>
                    <td><?php echo !empty($row['asal_sekolah']) ? htmlspecialchars($row['asal_sekolah']) : '-'; ?></td>
                    <td><?php echo badge_status($row['status']); ?></td>
                    <td><?php echo format_tanggal($row['tanggal_daftar']); ?></td>
                    <td><a href="<?php echo BASE_URL; ?>admin/detail.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary-custom"><i class="bi bi-eye me-1"></i>Detail</a></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <div class="empty-state"><i class="bi bi-inbox text-primary-custom" style="font-size:3.5rem;"></i><h5 class="mt-3">Belum Ada Pendaftar</h5><p>Data pendaftaran akan tampil setelah calon peserta didik mengisi formulir.</p></div>
    <?php endif; ?>
</div>

</div></div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
<?php if($total_pendaftar>0): ?>
// Donut Status
new Chart(document.getElementById('chartStatus'), {
    type: 'doughnut',
    data: {
        labels: ['Menunggu', 'Diterima', 'Ditolak'],
        datasets: [{ data: [<?php echo $total_menunggu; ?>, <?php echo $total_diterima; ?>, <?php echo $total_ditolak; ?>], backgroundColor: ['#d4ac0d','#27ae60','#e74c3c'], borderColor: ['#fff','#fff','#fff'], borderWidth: 3, hoverOffset: 8 }]
    },
    options: {
        responsive: true, maintainAspectRatio: false, cutout: '65%',
        plugins: {
            legend: { position: 'bottom', labels: { padding: 14, font: { size: 11 }, usePointStyle: true } },
            tooltip: { callbacks: { label: function(c) { const t=c.dataset.data.reduce((a,b)=>a+b,0); const p=t>0?Math.round((c.parsed/t)*100):0; return ' '+c.label+': '+c.parsed+' ('+p+'%)'; } } }
        }
    }
});

// Bar Kelengkapan
new Chart(document.getElementById('chartKelengkapan'), {
    type: 'bar',
    data: {
        labels: ['Data Lengkap', 'Belum Lengkap'],
        datasets: [{ data: [<?php echo $total_lengkap; ?>, <?php echo $total_belum_lengkap; ?>], backgroundColor: ['rgba(39,174,96,0.85)','rgba(230,126,22,0.85)'], borderColor: ['#27ae60','#e67e22'], borderWidth: 2, borderRadius: 8, borderSkipped: false }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        scales: {
            y: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 11 } }, grid: { color: 'rgba(0,0,0,0.05)' } },
            x: { ticks: { font: { size: 11 } }, grid: { display: false } }
        },
        plugins: { legend: { display: false }, tooltip: { callbacks: { label: function(c) { return ' '+c.parsed.y+' pendaftar'; } } } }
    }
});
<?php endif; ?>
</script>
<?php require_once __DIR__ . '/../includes/footer.php'; ?>
