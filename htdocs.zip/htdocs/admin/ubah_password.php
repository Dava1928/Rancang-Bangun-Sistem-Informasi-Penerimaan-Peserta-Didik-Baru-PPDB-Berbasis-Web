<?php
// =========================================================
// File: admin/ubah_password.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Halaman ubah password untuk admin
// =========================================================

$page_title = 'Ubah Password - PPDB Online MTS SA BINARAHMAH';
require_once __DIR__ . '/../includes/header.php';
require_admin();

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password_lama = $_POST['password_lama'] ?? '';
    $password_baru = $_POST['password_baru'] ?? '';
    $konfirmasi_baru = $_POST['konfirmasi_baru'] ?? '';
    $rate_key = 'admin_change_password_' . current_user_id();

    if (rate_limit_exceeded($rate_key, 6, 900)) {
        $error = 'Terlalu banyak percobaan ubah password. Silakan coba lagi sekitar 15 menit kemudian.';
    } elseif (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        rate_limit_hit($rate_key);
        $error = 'Sesi formulir tidak valid. Silakan muat ulang halaman dan coba lagi.';
    } elseif (empty($password_lama) || empty($password_baru) || empty($konfirmasi_baru)) {
        rate_limit_hit($rate_key);
        $error = 'Semua field wajib diisi.';
    } elseif (strlen($password_baru) < 8) {
        rate_limit_hit($rate_key);
        $error = 'Password baru minimal 8 karakter agar lebih aman.';
    } elseif (!preg_match('/[A-Za-z]/', $password_baru) || !preg_match('/[0-9]/', $password_baru)) {
        rate_limit_hit($rate_key);
        $error = 'Password baru harus mengandung huruf dan angka.';
    } elseif ($password_lama === $password_baru) {
        rate_limit_hit($rate_key);
        $error = 'Password baru tidak boleh sama dengan password lama.';
    } elseif ($password_baru !== $konfirmasi_baru) {
        rate_limit_hit($rate_key);
        $error = 'Konfirmasi password baru tidak cocok.';
    } else {
        $user_id = current_user_id();
        $user = db_fetch_one('SELECT password FROM users WHERE id = ? AND role = ? LIMIT 1', 'is', [$user_id, 'admin']);

        if (!$user) {
            $error = 'Data admin tidak ditemukan.';
        } elseif (!password_verify($password_lama, $user['password'])) {
            rate_limit_hit($rate_key);
            $error = 'Password lama yang Anda masukkan salah.';
        } else {
            $hash_baru = password_hash($password_baru, PASSWORD_DEFAULT);
            $ok = db_execute('UPDATE users SET password = ? WHERE id = ? AND role = ?', 'sis', [$hash_baru, $user_id, 'admin']);

            if ($ok) {
                rate_limit_clear($rate_key);
                rotate_csrf_token();
                set_flash('success', 'Password berhasil diubah. Gunakan password baru untuk login berikutnya.');
                header('Location: ' . BASE_URL . 'admin/dashboard.php');
                exit;
            }

            $error = 'Terjadi kesalahan saat menyimpan password. Silakan coba lagi.';
        }
    }
}

require_once __DIR__ . '/../includes/navbar.php';
?>

<div class="dashboard-wrapper">
    <div class="container">
        <?php echo get_flash(); ?>

        <!-- Header -->
        <div class="row align-items-center mb-4">
            <div class="col-md-8">
                <h2 class="page-title">Ubah Password</h2>
                <p class="page-subtitle mb-0">Perbarui password akun administrator PPDB Online.</p>
            </div>
            <div class="col-md-4 text-md-end">
                <a href="<?php echo BASE_URL; ?>admin/dashboard.php" class="btn btn-outline-primary-custom">
                    <i class="bi bi-arrow-left me-1"></i>Kembali ke Dashboard
                </a>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-8">
                <div class="content-card">
                    <div class="text-center mb-4">
                        <div style="width:64px;height:64px;background:linear-gradient(135deg,#1a5276,#2980b9);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 12px;font-size:1.8rem;color:white;">
                            <i class="bi bi-key-fill"></i>
                        </div>
                        <h5 class="fw-bold mb-1" style="color:#1a5276;">Ubah Password Admin</h5>
                        <p class="text-muted" style="font-size:0.88rem;">
                            Masukkan password lama dan password baru Anda untuk memperbarui akses.
                        </p>
                    </div>

                    <!-- Alert error -->
                    <?php if (!empty($error)) : ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($error) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Form -->
                    <form method="POST" autocomplete="off" novalidate>
                        <?php echo csrf_field(); ?>

                        <!-- Password Lama -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">
                                <i class="bi bi-lock-fill me-1" style="color:#1a5276;"></i>Password Lama
                                <span class="text-danger">*</span>
                            </label>
                            <div class="input-group">
                                <input type="password" id="pwd_lama" name="password_lama"
                                       class="form-control"
                                       placeholder="Masukkan password lama Anda"
                                       required>
                                <button type="button" class="btn btn-outline-secondary"
                                        onclick="togglePwd('pwd_lama', 'eye_lama')" tabindex="-1">
                                    <i class="bi bi-eye" id="eye_lama"></i>
                                </button>
                            </div>
                        </div>

                        <hr class="my-3">

                        <!-- Password Baru -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">
                                <i class="bi bi-lock me-1" style="color:#1a5276;"></i>Password Baru
                                <span class="text-danger">*</span>
                            </label>
                            <div class="input-group">
                                <input type="password" id="pwd_baru" name="password_baru"
                                       class="form-control"
                                       placeholder="Minimal 8 karakter, huruf dan angka"
                                       oninput="checkStrength(this.value)"
                                       required>
                                <button type="button" class="btn btn-outline-secondary"
                                        onclick="togglePwd('pwd_baru', 'eye_baru')" tabindex="-1">
                                    <i class="bi bi-eye" id="eye_baru"></i>
                                </button>
                            </div>
                            <!-- Indikator kekuatan password -->
                            <div class="mt-2">
                                <div class="progress" style="height:5px;border-radius:10px;">
                                    <div id="strengthBar" class="progress-bar" style="width:0%;border-radius:10px;transition:all 0.3s;"></div>
                                </div>
                                <small id="strengthLabel" class="text-muted">Belum diisi</small>
                            </div>
                        </div>

                        <!-- Konfirmasi Password Baru -->
                        <div class="mb-4">
                            <label class="form-label fw-semibold">
                                <i class="bi bi-lock-fill me-1" style="color:#1a5276;"></i>Konfirmasi Password Baru
                                <span class="text-danger">*</span>
                            </label>
                            <div class="input-group">
                                <input type="password" id="pwd_konfirm" name="konfirmasi_baru"
                                       class="form-control"
                                       placeholder="Ulangi password baru"
                                       oninput="checkMatch()"
                                       required>
                                <button type="button" class="btn btn-outline-secondary"
                                        onclick="togglePwd('pwd_konfirm', 'eye_konfirm')" tabindex="-1">
                                    <i class="bi bi-eye" id="eye_konfirm"></i>
                                </button>
                            </div>
                            <small id="matchLabel" class="text-muted"></small>
                        </div>

                        <!-- Info -->
                        <div class="alert alert-info border-0 mb-4" style="background:#eaf4fb;border-radius:8px;font-size:0.85rem;">
                            <i class="bi bi-info-circle-fill me-1"></i>
                            Setelah password berhasil diubah, Anda akan diarahkan kembali ke dashboard admin.
                        </div>

                        <!-- Tombol Submit -->
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary-custom py-2 fw-bold">
                                <i class="bi bi-shield-check me-2"></i>Simpan Password Baru
                            </button>
                            <a href="<?php echo BASE_URL; ?>admin/dashboard.php"
                               class="btn btn-outline-secondary" style="border-radius:8px;">
                                Batal
                            </a>
                        </div>

                    </form>
                </div>
            </div>
        </div>

    </div>
</div>

<script>
// Toggle show/hide password
function togglePwd(fieldId, iconId) {
    const f = document.getElementById(fieldId);
    const i = document.getElementById(iconId);
    if (f.type === 'password') {
        f.type = 'text';
        i.className = 'bi bi-eye-slash';
    } else {
        f.type = 'password';
        i.className = 'bi bi-eye';
    }
}

// Indikator kekuatan password
function checkStrength(val) {
    const bar   = document.getElementById('strengthBar');
    const label = document.getElementById('strengthLabel');
    if (!val) { bar.style.width='0%'; bar.className='progress-bar'; label.textContent='Belum diisi'; label.className='text-muted'; return; }
    let score = 0;
    if (val.length >= 6)  score++;
    if (val.length >= 10) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;
    const levels = [
        { w: '20%', cls: 'bg-danger',  txt: 'Sangat Lemah',  lcls: 'text-danger' },
        { w: '40%', cls: 'bg-warning', txt: 'Lemah',         lcls: 'text-warning' },
        { w: '60%', cls: 'bg-warning', txt: 'Cukup',         lcls: 'text-warning' },
        { w: '80%', cls: 'bg-info',    txt: 'Kuat',          lcls: 'text-info' },
        { w:'100%', cls: 'bg-success', txt: 'Sangat Kuat',   lcls: 'text-success' },
    ];
    const lvl = levels[score - 1] || levels[0];
    bar.style.width = lvl.w;
    bar.className   = 'progress-bar ' + lvl.cls;
    label.textContent = lvl.txt;
    label.className = 'small ' + lvl.lcls;
}

// Cek kecocokan konfirmasi password
function checkMatch() {
    const baru    = document.getElementById('pwd_baru').value;
    const konfirm = document.getElementById('pwd_konfirm').value;
    const lbl     = document.getElementById('matchLabel');
    if (!konfirm) { lbl.textContent = ''; return; }
    if (baru === konfirm) {
        lbl.textContent = '✅ Password cocok';
        lbl.className = 'small text-success';
    } else {
        lbl.textContent = '❌ Password tidak cocok';
        lbl.className = 'small text-danger';
    }
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
