<?php
// =========================================================
// File: profil.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Halaman company profile / profil madrasah
// =========================================================

$page_title = 'Profil Madrasah - PPDB Online MTS SA BINARAHMAH';

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<section class="profile-hero">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <span class="profile-badge">
                    <i class="bi bi-building-fill-check"></i>
                    Profil Madrasah
                </span>
                <h1 class="profile-title">MTS SA BINARAHMAH</h1>
                <p class="profile-lead">
                    MTS SA BINARAHMAH merupakan lembaga pendidikan Islam tingkat Madrasah Tsanawiyah
                    yang berkomitmen membentuk peserta didik beriman, bertaqwa, berilmu, berakhlak mulia,
                    dan mampu bersaing di era global. Melalui sistem PPDB Online, proses penerimaan peserta
                    didik baru dapat berjalan lebih cepat, transparan, dan terstruktur.
                </p>
            </div>
            <div class="col-lg-4 mt-4 mt-lg-0">
                <div class="hero-card">
                    <div class="hero-card-icon">
                        <i class="bi bi-award-fill"></i>
                    </div>
                    <h4 class="fw-bold text-primary-custom mb-3">Madrasah Berbasis Nilai Islam</h4>
                    <p class="text-muted mb-0">
                        Mengintegrasikan ilmu pengetahuan umum, pembentukan karakter, dan pembiasaan ibadah
                        dalam lingkungan belajar yang kondusif.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-padding">
    <div class="container">
        <div class="row g-4 align-items-center">
            <div class="col-lg-6">
                <span class="section-kicker">
                    <i class="bi bi-info-circle-fill"></i>
                    Tentang Kami
                </span>
                <h2 class="section-title">Membangun Generasi Berilmu dan Berakhlak</h2>
                <p class="text-muted" style="line-height: 1.9;">
                    Nama Binarahmah mencerminkan semangat membangun dengan kasih sayang. Madrasah ini
                    berupaya menghadirkan pendidikan yang tidak hanya menekankan prestasi akademik,
                    tetapi juga pembentukan akhlak, kedisiplinan, dan pemahaman agama Islam yang kuat.
                </p>
                <p class="text-muted mb-0" style="line-height: 1.9;">
                    Pengembangan sistem PPDB Online menjadi bagian dari upaya meningkatkan kualitas layanan
                    administrasi madrasah agar proses pendaftaran lebih mudah diakses oleh calon peserta didik
                    dan orang tua/wali.
                </p>
            </div>
            <div class="col-lg-6">
                <div class="soft-panel">
                    <div class="row g-3">
                        <div class="col-sm-6">
                            <div class="info-card text-center">
                                <div class="info-card-icon mx-auto">
                                    <i class="bi bi-mortarboard-fill"></i>
                                </div>
                                <h5>Jenjang</h5>
                                <p class="mb-0">Madrasah Tsanawiyah</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="info-card text-center">
                                <div class="info-card-icon mx-auto">
                                    <i class="bi bi-globe2"></i>
                                </div>
                                <h5>Layanan</h5>
                                <p class="mb-0">PPDB Online</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="info-card text-center">
                                <div class="info-card-icon mx-auto">
                                    <i class="bi bi-people-fill"></i>
                                </div>
                                <h5>Fokus</h5>
                                <p class="mb-0">Siswa dan Orang Tua</p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="info-card text-center">
                                <div class="info-card-icon mx-auto">
                                    <i class="bi bi-shield-check"></i>
                                </div>
                                <h5>Administrasi</h5>
                                <p class="mb-0">Digital dan Terpusat</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-padding bg-white">
    <div class="container">
        <div class="text-center">
            <span class="section-kicker">
                <i class="bi bi-stars"></i>
                Visi dan Misi
            </span>
            <h2 class="section-title">Arah Pengembangan Madrasah</h2>
            <p class="section-subtitle">
                Visi dan misi menjadi pedoman dalam penyelenggaraan pendidikan serta pengembangan layanan madrasah.
            </p>
        </div>

        <div class="row g-4">
            <div class="col-lg-5">
                <div class="vision-card h-100">
                    <h4 class="mb-3">
                        <i class="bi bi-eye-fill me-2"></i>
                        Visi
                    </h4>
                    <p class="fs-5 mb-0">
                        Terwujudnya peserta didik yang beriman, bertaqwa, berilmu,
                        berakhlak mulia, dan berdaya saing di era global.
                    </p>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="soft-panel h-100">
                    <h4 class="text-primary-custom fw-bold mb-3">
                        <i class="bi bi-list-check me-2"></i>
                        Misi
                    </h4>
                    <ul class="icon-list">
                        <li><i class="bi bi-check-circle-fill"></i><span>Melaksanakan pembelajaran yang efektif, efisien, dan menyenangkan berlandaskan nilai-nilai Islam.</span></li>
                        <li><i class="bi bi-check-circle-fill"></i><span>Menumbuhkan keimanan dan ketaqwaan melalui pembiasaan ibadah sehari-hari.</span></li>
                        <li><i class="bi bi-check-circle-fill"></i><span>Meningkatkan prestasi akademik dan non-akademik secara berkelanjutan.</span></li>
                        <li><i class="bi bi-check-circle-fill"></i><span>Mengembangkan kompetensi tenaga pendidik dan kependidikan secara profesional.</span></li>
                        <li><i class="bi bi-check-circle-fill"></i><span>Menciptakan lingkungan madrasah yang bersih, sehat, aman, dan kondusif.</span></li>
                        <li><i class="bi bi-check-circle-fill"></i><span>Menjalin kerja sama harmonis antara madrasah, orang tua, masyarakat, dan stakeholder.</span></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-padding">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-6">
                <div class="content-card h-100">
                    <h4 class="mb-3">
                        <i class="bi bi-bullseye me-2"></i>
                        Tujuan Madrasah
                    </h4>
                    <ul class="icon-list">
                        <li><i class="bi bi-arrow-right-circle-fill"></i><span>Meningkatkan kualitas pembelajaran yang seimbang antara ilmu umum dan ilmu agama Islam.</span></li>
                        <li><i class="bi bi-arrow-right-circle-fill"></i><span>Menghasilkan lulusan yang beriman, bertaqwa, berakhlak, berprestasi, dan siap melanjutkan pendidikan.</span></li>
                        <li><i class="bi bi-arrow-right-circle-fill"></i><span>Mengembangkan potensi peserta didik dalam bidang akademik, seni, olahraga, dan keagamaan.</span></li>
                        <li><i class="bi bi-arrow-right-circle-fill"></i><span>Meningkatkan kualitas sarana prasarana untuk mendukung proses belajar mengajar.</span></li>
                    </ul>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="content-card h-100">
                    <h4 class="mb-3">
                        <i class="bi bi-diagram-3-fill me-2"></i>
                        Struktur Organisasi
                    </h4>
                    <p class="text-muted" style="line-height: 1.8;">
                        Struktur organisasi madrasah disusun untuk mendukung kegiatan operasional secara terarah,
                        efektif, dan kolaboratif. Unsur organisasi meliputi kepala madrasah, wakil kepala bidang
                        kurikulum, kesiswaan, sarana prasarana, humas, guru, wali kelas, guru BK, tenaga administrasi,
                        serta petugas kebersihan dan keamanan.
                    </p>
                    <div class="row g-3 mt-2">
                        <div class="col-sm-6"><span class="badge bg-primary-custom w-100 py-2">Kepala Madrasah</span></div>
                        <div class="col-sm-6"><span class="badge bg-primary-custom w-100 py-2">Waka Kesiswaan</span></div>
                        <div class="col-sm-6"><span class="badge bg-primary-custom w-100 py-2">Tenaga Administrasi</span></div>
                        <div class="col-sm-6"><span class="badge bg-primary-custom w-100 py-2">Guru dan Wali Kelas</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section-padding bg-soft-blue">
    <div class="container">
        <div class="text-center">
            <span class="section-kicker">
                <i class="bi bi-laptop-fill"></i>
                Transformasi Digital
            </span>
            <h2 class="section-title">PPDB Online untuk Layanan yang Lebih Cepat</h2>
            <p class="section-subtitle">
                Sistem ini membantu madrasah mengubah proses pendaftaran manual menjadi layanan digital yang lebih rapi dan mudah dipantau.
            </p>
        </div>

        <div class="row g-4">
            <div class="col-md-4">
                <div class="info-card text-center">
                    <div class="info-card-icon mx-auto">
                        <i class="bi bi-person-plus-fill"></i>
                    </div>
                    <h5>Registrasi Online</h5>
                    <p>Calon peserta didik dapat membuat akun dan mengisi formulir dari mana saja.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-card text-center">
                    <div class="info-card-icon mx-auto">
                        <i class="bi bi-cloud-arrow-up-fill"></i>
                    </div>
                    <h5>Upload Dokumen</h5>
                    <p>Berkas persyaratan dapat diunggah langsung ke sistem dalam format PDF, JPG, atau PNG.</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="info-card text-center">
                    <div class="info-card-icon mx-auto">
                        <i class="bi bi-patch-check-fill"></i>
                    </div>
                    <h5>Verifikasi Admin</h5>
                    <p>Panitia PPDB dapat memeriksa data, menetapkan status, dan mencetak laporan.</p>
                </div>
            </div>
        </div>

        <div class="text-center mt-5">
            <?php if (!is_logged_in()) : ?>
                <a href="<?php echo BASE_URL; ?>register.php" class="btn btn-primary-custom btn-lg">
                    <i class="bi bi-person-plus me-2"></i>
                    Daftar Sekarang
                </a>
            <?php elseif (is_admin()) : ?>
                <a href="<?php echo BASE_URL; ?>admin/dashboard.php" class="btn btn-primary-custom btn-lg">
                    <i class="bi bi-speedometer2 me-2"></i>
                    Dashboard Admin
                </a>
            <?php else : ?>
                <a href="<?php echo BASE_URL; ?>user/dashboard.php" class="btn btn-primary-custom btn-lg">
                    <i class="bi bi-speedometer2 me-2"></i>
                    Dashboard User
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>

<?php
require_once __DIR__ . '/includes/footer.php';
?>
