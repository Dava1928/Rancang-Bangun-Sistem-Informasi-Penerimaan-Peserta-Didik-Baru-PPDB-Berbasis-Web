-- =========================================================
-- Database: ppdb_mts
-- Sistem PPDB Online MTS SA BINARAHMAH
-- Stack: PHP Native + MySQL
-- =========================================================



SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS dokumen;
DROP TABLE IF EXISTS data_orang_tua;
DROP TABLE IF EXISTS data_pribadi;
DROP TABLE IF EXISTS pendaftaran;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- =========================================================
-- Tabel: users
-- Menyimpan akun pengguna sistem, baik admin maupun user
-- =========================================================
CREATE TABLE users (
    id INT(11) NOT NULL AUTO_INCREMENT,
    nama_lengkap VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'user') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY unique_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- Tabel: pendaftaran
-- Menyimpan data utama pendaftaran calon peserta didik
-- =========================================================
CREATE TABLE pendaftaran (
    id INT(11) NOT NULL AUTO_INCREMENT,
    user_id INT(11) NOT NULL,
    no_pendaftaran VARCHAR(20) NOT NULL,
    status ENUM('menunggu', 'diterima', 'ditolak') NOT NULL DEFAULT 'menunggu',
    catatan_admin TEXT NULL,
    tanggal_daftar TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY unique_no_pendaftaran (no_pendaftaran),
    KEY idx_user_id (user_id),
    KEY idx_status (status),
    CONSTRAINT fk_pendaftaran_user
        FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- Tabel: data_pribadi
-- Menyimpan data pribadi calon peserta didik
-- =========================================================
CREATE TABLE data_pribadi (
    id INT(11) NOT NULL AUTO_INCREMENT,
    pendaftaran_id INT(11) NOT NULL,
    nama_lengkap VARCHAR(100) NOT NULL,
    nik VARCHAR(20) NOT NULL,
    nisn VARCHAR(20) NOT NULL,
    tempat_lahir VARCHAR(50) NOT NULL,
    tanggal_lahir DATE NOT NULL,
    jenis_kelamin ENUM('L', 'P') NOT NULL,
    agama VARCHAR(20) NOT NULL DEFAULT 'Islam',
    alamat TEXT NOT NULL,
    no_telepon VARCHAR(15) NOT NULL,
    asal_sekolah VARCHAR(100) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY unique_pendaftaran_data_pribadi (pendaftaran_id),
    KEY idx_nik (nik),
    KEY idx_nisn (nisn),
    CONSTRAINT fk_data_pribadi_pendaftaran
        FOREIGN KEY (pendaftaran_id)
        REFERENCES pendaftaran(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- Tabel: data_orang_tua
-- Menyimpan data orang tua/wali calon peserta didik
-- =========================================================
CREATE TABLE data_orang_tua (
    id INT(11) NOT NULL AUTO_INCREMENT,
    pendaftaran_id INT(11) NOT NULL,
    nama_ayah VARCHAR(100) NOT NULL,
    pekerjaan_ayah VARCHAR(50) NOT NULL,
    nama_ibu VARCHAR(100) NOT NULL,
    pekerjaan_ibu VARCHAR(50) NOT NULL,
    no_telepon_ortu VARCHAR(15) NOT NULL,
    penghasilan_ortu VARCHAR(50) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY unique_pendaftaran_data_orang_tua (pendaftaran_id),
    CONSTRAINT fk_data_orang_tua_pendaftaran
        FOREIGN KEY (pendaftaran_id)
        REFERENCES pendaftaran(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- Tabel: dokumen
-- Menyimpan path dokumen persyaratan yang diunggah user
-- =========================================================
CREATE TABLE dokumen (
    id INT(11) NOT NULL AUTO_INCREMENT,
    pendaftaran_id INT(11) NOT NULL,
    foto VARCHAR(255) NOT NULL,
    ijazah_sd VARCHAR(255) NOT NULL,
    akta_kelahiran VARCHAR(255) NOT NULL,
    kartu_keluarga VARCHAR(255) NOT NULL,
    uploaded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY unique_pendaftaran_dokumen (pendaftaran_id),
    CONSTRAINT fk_dokumen_pendaftaran
        FOREIGN KEY (pendaftaran_id)
        REFERENCES pendaftaran(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
-- Data admin default
-- Email    : admin@binarahmah.sch.id
-- Password : admin123
-- Password disimpan menggunakan password_hash PHP
-- =========================================================
INSERT INTO users (nama_lengkap, email, password, role)
VALUES (
    'Administrator PPDB',
    'admin@binarahmah.sch.id',
    '$2y$12$xXdiz0dEHa.KkgCIdFwe4e.hk9pEhOw4j9GCOccrm6l.abE6YWpLa',
    'admin'
);

-- =========================================================
-- Selesai
-- =========================================================
