<?php
$page_title = 'Kontak Panitia - PPDB Online MTS SA BINARAHMAH';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>
<section class="page-header"><div class="container"><span class="hero-badge"><i class="bi bi-headset"></i> Kontak Panitia</span><h1>Butuh Bantuan Pendaftaran?</h1><p>Hubungi panitia PPDB jika mengalami kendala saat registrasi, pengisian formulir, upload dokumen, atau cek status.</p></div></section>
<section class="section-padding"><div class="container"><div class="section-header"><span class="section-kicker"><i class="bi bi-telephone"></i> Informasi Kontak</span><h2 class="section-title">Hubungi Panitia PPDB</h2><p class="section-subtitle">Panitia siap membantu calon peserta didik dan orang tua/wali.</p></div><div class="row g-4"><div class="col-lg-5"><div class="contact-card"><h4 class="mb-3"><i class="bi bi-building me-2"></i>MTS SA BINARAHMAH</h4><p class="text-muted">Gunakan informasi kontak berikut untuk bantuan PPDB Online.</p>
<?php $items=[['bi-geo-alt-fill','Alamat Madrasah','Bogor, Jawa Barat'],['bi-whatsapp','WhatsApp Panitia','08xx-xxxx-xxxx'],['bi-envelope-fill','Email Sekolah','ppdb@binarahmah.sch.id'],['bi-clock-fill','Jam Pelayanan','Senin - Sabtu, 08.00 - 14.00 WIB']]; foreach($items as $it): ?>
<div class="contact-item"><div class="contact-item-icon"><i class="bi <?php echo $it[0]; ?>"></i></div><div><h6 class="fw-bold mb-1"><?php echo $it[1]; ?></h6><p class="text-muted mb-0"><?php echo $it[2]; ?></p></div></div>
<?php endforeach; ?>
<a href="mailto:ppdb@binarahmah.sch.id" class="btn btn-primary-custom mt-4"><i class="bi bi-envelope me-1"></i>Kirim Email</a></div></div><div class="col-lg-7"><div class="contact-card"><h4 class="mb-3"><i class="bi bi-map me-2"></i>Lokasi Madrasah</h4><p class="text-muted">Area ini dapat diganti dengan embed Google Maps sesuai lokasi resmi madrasah.</p><div class="map-placeholder"><div><i class="bi bi-geo-alt-fill" style="font-size:3rem;"></i><h5 class="mt-3">Area Peta Lokasi</h5><p class="mb-0">MTS SA BINARAHMAH<br>Bogor, Jawa Barat</p></div></div></div></div></div></div></section>
<section class="section-padding bg-white"><div class="container"><div class="section-header"><span class="section-kicker"><i class="bi bi-question-circle"></i> Bantuan PPDB</span><h2 class="section-title">Kendala yang Bisa Dibantu</h2></div><div class="row g-4">
<?php $help=[['bi-person-plus','Registrasi Akun'],['bi-pencil-square','Pengisian Formulir'],['bi-cloud-arrow-up','Upload Dokumen'],['bi-clipboard-check','Status Pendaftaran']]; foreach($help as $h): ?>
<div class="col-lg-3 col-md-6"><div class="info-card text-center"><div class="info-card-icon mx-auto"><i class="bi <?php echo $h[0]; ?>"></i></div><h5><?php echo $h[1]; ?></h5><p class="mb-0">Panitia dapat membantu jika ada kendala pada bagian ini.</p></div></div>
<?php endforeach; ?>
</div></div></section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
