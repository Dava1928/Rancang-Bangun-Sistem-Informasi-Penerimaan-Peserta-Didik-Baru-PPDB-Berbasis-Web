<?php
// =========================================================
// File: register.php
// Sistem PPDB Online MTS SA BINARAHMAH
// Halaman registrasi calon peserta didik
// =========================================================

$page_title = 'Registrasi - PPDB Online MTS SA BINARAHMAH';
require_once __DIR__ . '/includes/header.php';

redirect_if_logged_in();

$nama_lengkap = '';
$email = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_lengkap = trim($_POST['nama_lengkap'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $konfirmasi_password = $_POST['konfirmasi_password'] ?? '';
    $rate_key = 'register_' . hash('sha256', client_ip() . '|' . $email);

    if (rate_limit_exceeded($rate_key, 8, 900)) {
        $error = 'Terlalu banyak percobaan registrasi. Silakan coba lagi sekitar 15 menit kemudian.';
    } elseif (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        rate_limit_hit($rate_key);
        $error = 'Sesi formulir tidak valid. Silakan muat ulang halaman dan coba lagi.';
    } elseif (empty($nama_lengkap) || empty($email) || empty($password) || empty($konfirmasi_password)) {
        rate_limit_hit($rate_key);
        $error = 'Semua field wajib diisi.';
    } elseif (strlen($nama_lengkap) < 3 || strlen($nama_lengkap) > 100) {
        rate_limit_hit($rate_key);
        $error = 'Nama lengkap harus 3 sampai 100 karakter.';
    } elseif (!preg_match("/^[\\p{L}\\s'.-]+$/u", $nama_lengkap)) {
        rate_limit_hit($rate_key);
        $error = 'Nama lengkap hanya boleh berisi huruf, spasi, titik, apostrof, dan tanda hubung.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 120) {
        rate_limit_hit($rate_key);
        $error = 'Format email tidak valid.';
    } elseif (strlen($password) < 8) {
        rate_limit_hit($rate_key);
        $error = 'Password minimal 8 karakter agar lebih aman.';
    } elseif (!preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        rate_limit_hit($rate_key);
        $error = 'Password harus mengandung huruf dan angka.';
    } elseif ($password !== $konfirmasi_password) {
        rate_limit_hit($rate_key);
        $error = 'Konfirmasi password tidak sama.';
    } elseif (email_exists($email)) {
        rate_limit_hit($rate_key);
        $error = 'Email sudah terdaftar. Silakan gunakan email lain atau login.';
    } else {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        $ok = db_execute(
            'INSERT INTO users (nama_lengkap, email, password, role) VALUES (?, ?, ?, ?)',
            'ssss',
            [$nama_lengkap, $email, $password_hash, 'user']
        );

        if ($ok) {
            rate_limit_clear($rate_key);
            rotate_csrf_token();
            set_flash('success', 'Registrasi berhasil. Silakan login menggunakan akun Anda.');
            header('Location: ' . BASE_URL . 'login.php');
            exit;
        }

        $error = 'Registrasi gagal. Silakan coba lagi.';
    }
}

require_once __DIR__ . '/includes/navbar.php';
?>

<section class="auth-wrapper">
    <div class="container">
        <div class="row justify-content-center align-items-center g-4">
            <div class="col-lg-5">
                <div class="auth-card">
                    <div class="text-center mb-4">
                        <div class="auth-icon"><i class="bi bi-person-plus"></i></div>
                        <h3>Daftar Akun PPDB</h3>
                        <p class="text-muted mb-0">Buat akun untuk mulai mengisi formulir pendaftaran online.</p>
                    </div>

                    <?php echo get_flash(); ?>

                    <?php if (!empty($error)) : ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i>
                            <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form action="" method="POST" autocomplete="off">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="nama_lengkap" class="form-label required">Nama Lengkap</label>
                            <div class="input-icon-group">
                                <i class="bi bi-person input-icon"></i>
                                <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control" placeholder="Masukkan nama lengkap" value="<?php echo htmlspecialchars($nama_lengkap); ?>" required>
                            </div>
                            <div class="form-text">Gunakan nama calon peserta didik sesuai dokumen resmi.</div>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label required">Email Aktif</label>
                            <div class="input-icon-group">
                                <i class="bi bi-envelope input-icon"></i>
                                <input type="email" name="email" id="email" class="form-control" placeholder="Contoh: nama@email.com" value="<?php echo htmlspecialchars($email); ?>" required>
                            </div>
                            <div class="form-text">Email digunakan untuk login ke sistem PPDB Online.</div>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label required">Password</label>
                            <div class="input-icon-group">
                                <i class="bi bi-lock input-icon"></i>
                                <input type="password" name="password" id="password" class="form-control" placeholder="Minimal 8 karakter, huruf dan angka" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="konfirmasi_password" class="form-label required">Konfirmasi Password</label>
                            <div class="input-icon-group">
                                <i class="bi bi-shield-lock input-icon"></i>
                                <input type="password" name="konfirmasi_password" id="konfirmasi_password" class="form-control" placeholder="Ulangi password" required>
                            </div>
                            <div id="passwordMatchText" class="form-text">Pastikan konfirmasi password sama dengan password.</div>
                        </div>

                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="showPassword">
                                <label class="form-check-label small text-muted" for="showPassword">Tampilkan password</label>
                            </div>
                            <a href="<?php echo BASE_URL; ?>panduan.php" class="small text-primary-custom fw-semibold">Lihat panduan</a>
                        </div>

                        <div class="alert alert-info">
                            <i class="bi bi-info-circle-fill me-2"></i>
                            Setelah registrasi berhasil, login untuk mengisi formulir pendaftaran secara bertahap.
                        </div>

                        <div class="d-grid mb-3">
                            <button type="submit" class="btn btn-primary-custom" data-loading-text="Mendaftarkan">
                                <i class="bi bi-person-plus me-1"></i>Daftar Sekarang
                            </button>
                        </div>

                        <div class="text-center">
                            <p class="mb-0">Sudah punya akun? <a href="<?php echo BASE_URL; ?>login.php" class="text-primary-custom fw-semibold">Login di sini</a></p>
                        </div>
                    </form>
                </div>

                <div class="text-center mt-3">
                    <a href="<?php echo BASE_URL; ?>index.php" class="text-muted"><i class="bi bi-arrow-left me-1"></i>Kembali ke Beranda</a>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="auth-side-card">
                    <div class="position-relative z-2">
                        <span class="badge bg-light text-primary-custom mb-3"><i class="bi bi-stars me-1"></i>Pendaftaran Online</span>
                        <h2 class="fw-850 mb-3">Mulai Proses PPDB MTS SA BINARAHMAH</h2>
                        <p class="mb-4">
                            Dengan satu akun, calon peserta didik dapat mengisi formulir, upload dokumen,
                            melihat status verifikasi, dan mencetak bukti pendaftaran.
                        </p>

                        <div class="row g-3 mb-4">
                            <div class="col-sm-6"><div class="p-3 rounded-custom" style="background-color: rgba(255,255,255,0.14);"><i class="bi bi-card-checklist fs-3 mb-2 d-block"></i><strong class="d-block">Formulir Bertahap</strong><span class="small text-white-50">Data pribadi, orang tua, dokumen.</span></div></div>
                            <div class="col-sm-6"><div class="p-3 rounded-custom" style="background-color: rgba(255,255,255,0.14);"><i class="bi bi-cloud-arrow-up fs-3 mb-2 d-block"></i><strong class="d-block">Upload Dokumen</strong><span class="small text-white-50">PDF, JPG, PNG maksimal 2MB.</span></div></div>
                            <div class="col-sm-6"><div class="p-3 rounded-custom" style="background-color: rgba(255,255,255,0.14);"><i class="bi bi-clipboard-check fs-3 mb-2 d-block"></i><strong class="d-block">Cek Status</strong><span class="small text-white-50">Pantau verifikasi admin.</span></div></div>
                            <div class="col-sm-6"><div class="p-3 rounded-custom" style="background-color: rgba(255,255,255,0.14);"><i class="bi bi-printer fs-3 mb-2 d-block"></i><strong class="d-block">Cetak Bukti</strong><span class="small text-white-50">Simpan bukti pendaftaran.</span></div></div>
                        </div>

                        <h5 class="fw-850 mb-3">Dokumen yang perlu disiapkan:</h5>
                        <ul class="list-unstyled mb-0">
                            <li class="mb-2"><i class="bi bi-check-circle-fill me-2"></i>Pas foto calon peserta didik.</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill me-2"></i>Ijazah/STTB SD/MI atau surat keterangan lulus.</li>
                            <li class="mb-2"><i class="bi bi-check-circle-fill me-2"></i>Akta kelahiran.</li>
                            <li><i class="bi bi-check-circle-fill me-2"></i>Kartu keluarga.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const showPassword = document.getElementById('showPassword');
    const passwordInput = document.getElementById('password');
    const confirmInput = document.getElementById('konfirmasi_password');
    const matchText = document.getElementById('passwordMatchText');

    if (showPassword && passwordInput && confirmInput) {
        showPassword.addEventListener('change', function () {
            const type = this.checked ? 'text' : 'password';
            passwordInput.type = type;
            confirmInput.type = type;
        });
    }

    function checkPasswordMatch() {
        if (!passwordInput || !confirmInput || !matchText) return;
        if (confirmInput.value.length === 0) {
            matchText.className = 'form-text';
            matchText.innerHTML = 'Pastikan konfirmasi password sama dengan password.';
            return;
        }
        if (passwordInput.value === confirmInput.value) {
            matchText.className = 'form-text text-success fw-semibold';
            matchText.innerHTML = '<i class="bi bi-check-circle me-1"></i>Password cocok.';
        } else {
            matchText.className = 'form-text text-danger fw-semibold';
            matchText.innerHTML = '<i class="bi bi-x-circle me-1"></i>Password belum cocok.';
        }
    }

    if (passwordInput && confirmInput) {
        passwordInput.addEventListener('input', checkPasswordMatch);
        confirmInput.addEventListener('input', checkPasswordMatch);
    }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
